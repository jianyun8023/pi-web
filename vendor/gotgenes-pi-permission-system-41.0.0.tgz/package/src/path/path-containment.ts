import type { PathFlavor } from "./path-flavor";
import { isSafeSystemPath } from "./safe-system-paths";

/**
 * Pure geometry: is `canonicalPath` outside `canonicalCwd`?
 *
 * Both operands must already be canonical (symlink-resolved, win32-lowercased)
 * — the caller prepares them (see {@link PathNormalizer.isBoundaryOutsideWorkingDirectory}).
 * This predicate touches no filesystem and does no derivation; the containment
 * geometry lives on {@link PathFlavor.isWithin}.
 */
export function isPathOutsideWorkingDirectory(
  canonicalPath: string,
  canonicalCwd: string,
  flavor: PathFlavor,
): boolean {
  if (!canonicalCwd || !canonicalPath) {
    return false;
  }
  if (isSafeSystemPath(canonicalPath)) {
    return false;
  }
  return !flavor.isWithin(canonicalPath, canonicalCwd);
}
