import type { ExtensionContext } from "@earendil-works/pi-coding-agent";
import type { AuthorizerSelectionLifecycle } from "#src/authority/authorizer-selection";
import type { ForwardingController } from "#src/authority/forwarding-manager";
import type { DeclaredCommandEffects } from "#src/config/command-effects-config";
import type { ShellToolsConfig } from "#src/config/config-schema";
import type { SessionConfigStore } from "#src/config/config-store";
import type { PermissionSystemExtensionConfig } from "#src/config/extension-config";
import type { ExtensionPaths } from "#src/config/extension-paths";
import { syncPermissionSystemStatus } from "#src/config/status";
import type { SkillPromptEntry } from "#src/exposure/skill-prompt-sanitizer";
import {
  ToolSurfaceBaseline,
  type ToolSurfaceObservation,
  type ToolSurfaceResolution,
} from "#src/exposure/tool-surface-baseline";
import type { ToolCallGateInputs } from "#src/handlers/gates/tool-call-gate-pipeline";
import type { PathFlavor } from "#src/path/path-flavor";
import { PathNormalizer } from "#src/path/path-normalizer";
import type { InfrastructureReadScope } from "#src/path/pi-infrastructure-read";
import type { ScopedPermissionManager } from "#src/policy/permission-manager";
import {
  resolveToolPreviewLimits,
  type ToolPreviewFormatterOptions,
} from "#src/tool-input/tool-preview-formatter";
import {
  getActiveAgentName,
  getActiveAgentNameFromSystemPrompt,
} from "./active-agent";
import type { SessionRules } from "./session-rules";

/**
 * Encapsulates all mutable session state and exposes operations instead of
 * fields.
 *
 * Replaces the `SessionState` interface + scattered handler field mutations
 * with a single class that owns the `PermissionManager`, `SessionRules`,
 * cache keys, skill entries, and runtime context.
 *
 * Constructor deps:
 * - `ExtensionPaths` — immutable path constants
 * - `ForwardingController` — polling lifecycle
 * - `SessionConfigStore` — owns extension config; provides refresh, log, read
 * - `AuthorizerSelectionLifecycle` — authorizer-selection lifecycle forwarded via activate/deactivate
 */
export class PermissionSession implements ToolCallGateInputs {
  private context: ExtensionContext | null = null;
  private skillEntries: SkillPromptEntry[] = [];
  private knownAgentName: string | null = null;
  private pathNormalizer: PathNormalizer;
  private readonly toolSurfaceBaseline = new ToolSurfaceBaseline();

  constructor(
    private readonly paths: ExtensionPaths,
    private readonly forwarding: ForwardingController,
    private readonly permissionManager: ScopedPermissionManager,
    private readonly sessionRules: SessionRules,
    private readonly configStore: SessionConfigStore,
    private readonly authorizerSelection: AuthorizerSelectionLifecycle,
    private readonly flavor: PathFlavor,
  ) {
    // Placeholder until the first activate(ctx) binds the real cwd; every gate
    // evaluate runs after activate (handleToolCall activates first), so this
    // empty-cwd value is never read.
    this.pathNormalizer = new PathNormalizer(flavor, "");
  }

  // ── Context lifecycle ──────────────────────────────────────────────────

  /**
   * Store the current extension context, rebuild the path normalizer for its
   * cwd, start forwarding, and activate the gateway.
   *
   * The normalizer is (re)built here rather than only at `resetForNewSession`
   * so it always tracks the active context's cwd — `ctx.cwd` is stable within a
   * session, so this is a no-op rebuild in production, but it closes the
   * fail-open gap if a tool call ever arrives before `session_start`.
   */
  activate(ctx: ExtensionContext): void {
    this.context = ctx;
    this.pathNormalizer = new PathNormalizer(this.flavor, ctx.cwd);
    this.forwarding.start(ctx);
    this.authorizerSelection.activate(ctx);
  }

  /** Clear the context, stop forwarding, and deactivate the authorizer selection. */
  deactivate(): void {
    this.context = null;
    this.forwarding.stop();
    this.authorizerSelection.deactivate();
  }

  /** Return the current runtime context, or null if not activated. */
  getRuntimeContext(): ExtensionContext | null {
    return this.context;
  }

  // ── UI notifications ────────────────────────────────────────────────────

  /** Surface a warning message to the user via the active UI context, if any. */
  notify(message: string): void {
    this.context?.ui.notify(message, "warning");
  }

  // ── Session lifecycle ────────────────────────────────────────────────────

  /**
   * Reset all mutable state for a new session.
   *
   * Configures the injected PermissionManager for `ctx.cwd` (or global-only
   * when `projectTrusted` is `false`, withholding the project cwd so an
   * untrusted project's policy scopes are not loaded, #644), clears skill
   * entries, and activates the new context.
   */
  resetForNewSession(ctx: ExtensionContext, projectTrusted: boolean): void {
    this.permissionManager.configureForCwd(
      projectTrusted ? ctx.cwd : undefined,
    );
    this.skillEntries = [];
    this.toolSurfaceBaseline.reset();
    this.activate(ctx);
  }

  /**
   * Shut down the session: clear rules, skill entries, and deactivate
   * context + forwarding.
   */
  shutdown(): void {
    this.sessionRules.clear();
    this.skillEntries = [];
    this.toolSurfaceBaseline.reset();
    this.deactivate();
  }

  /**
   * Reload permission manager and clear skill entries for the current context.
   * Used on config reload (e.g. `resources_discover` with reason "reload").
   *
   * When `projectTrusted` is `false` the project cwd is withheld, so a reload
   * in an untrusted project reloads only global policy; a trust grant on a
   * later reload re-includes the project scope (#644).
   */
  reload(projectTrusted: boolean): void {
    this.permissionManager.configureForCwd(
      projectTrusted ? this.context?.cwd : undefined,
    );
    this.skillEntries = [];
    // The tool-surface baseline deliberately survives a reload: a reload is
    // when a relaxed policy arrives, and reseeding from the already-filtered
    // active set would strand the tool it just un-denied (#873).
  }

  // ── Tool surface ───────────────────────────────────────────────────────

  /**
   * Answer which tools the agent may see this turn, applying `isExposed` to
   * the session's pre-filter tool surface rather than to the previous turn's
   * filtered result.
   */
  resolveExposedTools(
    observation: ToolSurfaceObservation,
    isExposed: (toolName: string) => boolean,
  ): ToolSurfaceResolution {
    return this.toolSurfaceBaseline.resolveExposed(observation, isExposed);
  }

  // ── Skill entries ──────────────────────────────────────────────────────

  getActiveSkillEntries(): SkillPromptEntry[] {
    return this.skillEntries;
  }

  setActiveSkillEntries(entries: SkillPromptEntry[]): void {
    this.skillEntries = entries;
  }

  // ── Agent name ─────────────────────────────────────────────────────────

  /**
   * Resolve the active agent name from the session context, system prompt,
   * or last known name. Updates lastKnownActiveAgentName as a side effect.
   */
  resolveAgentName(
    ctx: ExtensionContext,
    systemPrompt?: string,
  ): string | null {
    const fromSession = getActiveAgentName(ctx);
    if (fromSession) {
      this.knownAgentName = fromSession;
      return fromSession;
    }
    const fromSystemPrompt = getActiveAgentNameFromSystemPrompt(systemPrompt);
    if (fromSystemPrompt) {
      this.knownAgentName = fromSystemPrompt;
      return fromSystemPrompt;
    }
    return this.knownAgentName;
  }

  // Read by the `index.ts` config-modal adapter closure:
  // `permissionManager.getComposedConfigRules(session.lastKnownActiveAgentName ?? undefined)`.
  get lastKnownActiveAgentName(): string | null {
    return this.knownAgentName;
  }

  // ── Config ─────────────────────────────────────────────────────────────

  /**
   * Reload merged config from disk, then bring the status bar in step with it.
   *
   * When `projectTrusted` is `false`, the project scope is withheld so an
   * untrusted project's runtime config is not merged (#644).
   *
   * The status sync lives here rather than in `ConfigStore` because it is a UI
   * side effect of the session, keyed on the session's context: the store
   * loads and answers, and needs no ctx to do it (#933). Both drivers
   * (`session_start` and every `before_agent_start`) call this one method, so
   * the sync has a single home rather than one copy per handler.
   */
  refreshConfig(
    ctx: ExtensionContext | undefined,
    projectTrusted: boolean,
  ): void {
    this.configStore.refresh(ctx?.cwd, projectTrusted);
    if (ctx?.hasUI) {
      syncPermissionSystemStatus(ctx, this.configStore.current());
    }
  }

  /** Write the resolved config path set to the review and debug logs. */
  logResolvedConfigPaths(): void {
    this.configStore.logResolvedPaths(this.context?.cwd);
  }

  /** Read current extension config. */
  get config(): PermissionSystemExtensionConfig {
    return this.configStore.current();
  }

  // ── Infrastructure paths ───────────────────────────────────────────────

  /**
   * Where infrastructure reads are auto-allowed: the static roots from
   * `ExtensionPaths` plus the config-derived `piInfrastructureReadPaths`.
   */
  getInfrastructureReadScope(): InfrastructureReadScope {
    return {
      dirs: [
        ...this.paths.piInfrastructureDirs,
        ...(this.config.piInfrastructureReadPaths ?? []),
      ],
      excludedDirs: this.paths.piInfrastructureExcludedDirs,
    };
  }

  /**
   * Resolved tool-preview formatter options from the current config.
   *
   * Replaces the handler's `resolveToolPreviewLimits(session.config)` reach
   * so the pipeline reads a clean value rather than pulling raw config.
   */
  getToolPreviewLimits(): ToolPreviewFormatterOptions {
    return resolveToolPreviewLimits();
  }

  /**
   * The configured shell-tool aliases (`shellTools`), mapping a non-`bash` tool
   * name to the input arguments holding its command and optional working
   * directory. `undefined` when no aliases are configured. Consumed by the
   * gate pipeline's {@link resolveShellInvocation} consult (#574).
   */
  getShellToolAliases(): ShellToolsConfig | undefined {
    return this.config.shellTools;
  }

  /**
   * The user's `commandEffects` declarations, scope stamped, which the gate
   * pipeline hands to `BashProgram.parse` so a declared command's operands
   * route by their declared effect.
   */
  getCommandEffects(): DeclaredCommandEffects {
    return this.configStore.declaredCommandEffects();
  }

  // ── Path normalization ────────────────────────────────────────────────

  /**
   * The session's {@link PathNormalizer}, carrying the host path flavor and the
   * session cwd. Rebuilt on every `resetForNewSession` so a session switch
   * rebinds the cwd.
   */
  getPathNormalizer(): PathNormalizer {
    return this.pathNormalizer;
  }
}
